package me.Gui.gui.modules;

import java.util.concurrent.ThreadLocalRandom;
import me.Gui.gui.client.GuiClient;
import me.Gui.gui.modules.HackModule;
import me.Gui.gui.modules.ModuleId;
import net.minecraft.client.MinecraftClient;

public final class SpammerUtil {
    private static long nextSendAtMs = 0L;

    private SpammerUtil() {
    }

    public static void tick(MinecraftClient client) {
        boolean anti;
        long now;
        if (client == null || client.player == null) {
            SpammerUtil.reset();
            return;
        }
        if (!SpammerUtil.isEnabled()) {
            SpammerUtil.reset();
            return;
        }
        if (client.getNetworkHandler() == null) {
            return;
        }
        if (client.currentScreen != null) {
            return;
        }
        String base = GuiClient.CONFIG.spammerMessage;
        if (base == null) {
            base = "";
        }
        if ((base = base.trim()).isEmpty()) {
            return;
        }
        int delaySec = GuiClient.CONFIG.spammerDelaySec;
        if (delaySec < 1) {
            delaySec = 1;
        }
        if ((now = System.currentTimeMillis()) < nextSendAtMs) {
            return;
        }
        Object msg = base;
        boolean bl = anti = GuiClient.CONFIG.spammerAntiSpam != null && GuiClient.CONFIG.spammerAntiSpam != false;
        if (anti) {
            int rand = ThreadLocalRandom.current().nextInt(100, 1000);
            msg = (String)msg + " " + rand;
        }
        if (((String)msg).length() > 256) {
            msg = ((String)msg).substring(0, 256);
        }
        client.getNetworkHandler().sendChatMessage((String)msg);
        nextSendAtMs = now + (long)delaySec * 1000L;
    }

    private static boolean isEnabled() {
        HackModule m = GuiClient.MODULES.byId(ModuleId.SPAMMER);
        return m != null && m.isEnabled();
    }

    private static void reset() {
        nextSendAtMs = 0L;
    }
}

