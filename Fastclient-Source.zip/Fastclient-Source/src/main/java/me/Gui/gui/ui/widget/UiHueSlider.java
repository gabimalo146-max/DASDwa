package me.Gui.gui.ui.widget;

import me.Gui.gui.ui.render.Rounded;
import me.Gui.gui.ui.widget.UiSlider;
import net.minecraft.client.gui.DrawContext;

public class UiHueSlider
extends UiSlider {
    public UiHueSlider(int x, int y, int w, int h, float initial01, UiSlider.ValueChanged onChange) {
        super(x, y, w, h, null, initial01, onChange);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, int bg, int fill, int text) {
        float r = Math.min((float)this.h * 0.45f, 8.0f);
        Rounded.rect(ctx, this.x, this.y, this.w, this.h, r, bg);
        int pad = 8;
        int barY1 = this.y + 6;
        int barY2 = this.y + this.h - 6;
        int startX = this.x + pad;
        int endX = this.x + this.w - pad;
        int span = Math.max(1, endX - startX);
        int segs = Math.max(48, span);
        for (int i = 0; i < segs; ++i) {
            int c;
            float t = (float)i / (float)(segs - 1);
            if (t >= 0.97f) {
                float p = Math.min(1.0f, (t - 0.97f) / 0.03f);
                c = UiHueSlider.lerpRgb(UiHueSlider.hsvToRgb(0.0f, 1.0f, 1.0f), -1, p);
            } else {
                c = UiHueSlider.hsvToRgb(t, 1.0f, 1.0f);
            }
            int sx1 = startX + (int)((float)span * ((float)i / (float)segs));
            int sx2 = startX + (int)((float)span * ((float)(i + 1) / (float)segs));
            if (sx2 <= sx1) {
                sx2 = sx1 + 1;
            }
            ctx.fill(sx1, barY1, sx2, barY2, c);
        }
        int markerX = startX + (int)((float)span * this.value);
        ctx.fill(markerX - 1, barY1 - 2, markerX + 1, barY2 + 2, -1);
    }

    @Override
    protected void setFromMouse(double mx) {
        int pad = 8;
        double t = (mx - (double)(this.x + pad)) / (double)(this.w - pad * 2);
        this.value = this.clamp01((float)t);
        if (this.onChange != null) {
            this.onChange.onChanged(this.value);
        }
    }

    private static int hsvToRgb(float h, float s, float v) {
        h = (h % 1.0f + 1.0f) % 1.0f;
        float i = (float)Math.floor(h * 6.0f);
        float f = h * 6.0f - i;
        float p = v * (1.0f - s);
        float q = v * (1.0f - f * s);
        float t = v * (1.0f - (1.0f - f) * s);
        int m = (int)i % 6;
        float r;
        float g;
        float b;
        switch (m) {
            case 0: {
                r = v;
                g = t;
                b = p;
                break;
            }
            case 1: {
                r = q;
                g = v;
                b = p;
                break;
            }
            case 2: {
                r = p;
                g = v;
                b = t;
                break;
            }
            case 3: {
                r = p;
                g = q;
                b = v;
                break;
            }
            case 4: {
                r = t;
                g = p;
                b = v;
                break;
            }
            default: {
                r = v;
                g = p;
                b = q;
                break;
            }
        }
        return 0xFF000000 | (int)(r * 255.0f) << 16 | (int)(g * 255.0f) << 8 | (int)(b * 255.0f);
    }

    private static int lerpRgb(int from, int to, float t) {
        float clamped = Math.max(0.0f, Math.min(1.0f, t));
        int fr = from >> 16 & 0xFF;
        int fg = from >> 8 & 0xFF;
        int fb = from & 0xFF;
        int tr = to >> 16 & 0xFF;
        int tg = to >> 8 & 0xFF;
        int tb = to & 0xFF;
        int r = Math.round((float)fr + (float)(tr - fr) * clamped);
        int g = Math.round((float)fg + (float)(tg - fg) * clamped);
        int b = Math.round((float)fb + (float)(tb - fb) * clamped);
        return 0xFF000000 | r << 16 | g << 8 | b;
    }
}

