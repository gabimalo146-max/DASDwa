package me.Gui.gui.modules;

import me.Gui.gui.client.GuiClient;
import me.Gui.gui.modules.HackModule;
import me.Gui.gui.modules.ModuleId;

public final class TpAcceptSoundsUtil {
    private TpAcceptSoundsUtil() {
    }

    public static boolean isEnabled() {
        HackModule m = GuiClient.MODULES.byId(ModuleId.TPACCEPT_SOUNDS);
        return m != null && m.isEnabled();
    }
}

