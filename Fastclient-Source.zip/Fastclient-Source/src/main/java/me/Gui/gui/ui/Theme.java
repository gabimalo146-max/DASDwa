package me.Gui.gui.ui;

import me.Gui.gui.client.GuiClient;
import me.Gui.gui.config.GuiConfig;

public class Theme {
    public static int argb(int a, int r, int g, int b) {
        a = Theme.clamp255(a);
        r = Theme.clamp255(r);
        g = Theme.clamp255(g);
        b = Theme.clamp255(b);
        return a << 24 | r << 16 | g << 8 | b;
    }

    public static int withAlpha(int rgb, int a) {
        a = Theme.clamp255(a);
        return a << 24 | rgb & 0xFFFFFF;
    }

    private static int clamp255(int v) {
        return Math.max(0, Math.min(255, v));
    }

    private static float clamp01(float v) {
        return Math.max(0.0f, Math.min(1.0f, v));
    }

    public static int accentColor(long nowMs) {
        GuiConfig cfg = GuiClient.CONFIG;
        return switch (cfg.colorMode) {
            default -> throw new MatchException(null, null);
            case GuiConfig.ColorMode.SINGLE -> Theme.hsvToRgb(cfg.singleHue, 1.0f, 1.0f);
            case GuiConfig.ColorMode.GRADIENT -> Theme.gradient(nowMs, cfg.gradHueA, cfg.gradHueB, cfg.gradSpeed);
            case GuiConfig.ColorMode.RAINBOW -> Theme.rainbow(nowMs, cfg.rainbowSpeed);
        };
    }

    private static int rainbow(long nowMs, float speed01) {
        float s = Theme.clamp01(speed01);
        double period = 120000.0 - (double)s * 118000.0;
        double t = (double)nowMs / period % 1.0;
        float hue = (float)t;
        return Theme.hsvToRgb(hue, 1.0f, 1.0f);
    }

    private static int gradient(long nowMs, float a, float b, float speed01) {
        float s = Theme.clamp01(speed01);
        double period = 90000.0 - (double)s * 87500.0;
        double t = (double)nowMs / period % 1.0;
        float p = (float)(t < 0.5 ? t * 2.0 : 2.0 - t * 2.0);
        int ca = Theme.hsvToRgb(a, 1.0f, 1.0f);
        int cb = Theme.hsvToRgb(b, 1.0f, 1.0f);
        return Theme.lerpColor(ca, cb, p);
    }

    private static int lerpColor(int a, int b, float t) {
        int aA = a >>> 24 & 0xFF;
        int aR = a >>> 16 & 0xFF;
        int aG = a >>> 8 & 0xFF;
        int aB = a & 0xFF;
        int bA = b >>> 24 & 0xFF;
        int bR = b >>> 16 & 0xFF;
        int bG = b >>> 8 & 0xFF;
        int bB = b & 0xFF;
        int oA = Math.round((float)aA + (float)(bA - aA) * t);
        int oR = Math.round((float)aR + (float)(bR - aR) * t);
        int oG = Math.round((float)aG + (float)(bG - aG) * t);
        int oB = Math.round((float)aB + (float)(bB - aB) * t);
        return Theme.clamp255(oA) << 24 | Theme.clamp255(oR) << 16 | Theme.clamp255(oG) << 8 | Theme.clamp255(oB);
    }

    public static int hsvToRgb(float h, float s, float v) {
        h = (h % 1.0f + 1.0f) % 1.0f;
        s = Theme.clamp01(s);
        v = Theme.clamp01(v);
        float i = (float)Math.floor(h * 6.0f);
        float f = h * 6.0f - i;
        float p = v * (1.0f - s);
        float q = v * (1.0f - f * s);
        float t = v * (1.0f - (1.0f - f) * s);
        int m = (int)i % 6;
        float r;
        float g;
        float b;
        switch (m) {
            case 0: {
                r = v;
                g = t;
                b = p;
                break;
            }
            case 1: {
                r = q;
                g = v;
                b = p;
                break;
            }
            case 2: {
                r = p;
                g = v;
                b = t;
                break;
            }
            case 3: {
                r = p;
                g = q;
                b = v;
                break;
            }
            case 4: {
                r = t;
                g = p;
                b = v;
                break;
            }
            default: {
                r = v;
                g = p;
                b = q;
                break;
            }
        }
        return 0xFF000000 | (int)(r * 255.0f) << 16 | (int)(g * 255.0f) << 8 | (int)(b * 255.0f);
    }
}

