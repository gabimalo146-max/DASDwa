package me.Gui.gui.modules;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import me.Gui.gui.client.GuiClient;
import me.Gui.gui.modules.HackModule;
import me.Gui.gui.modules.ModuleId;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.registry.Registries;

public final class XrayUtil {
    private static final Set<String> ALLOWED = new HashSet<String>();
    private static boolean dirty = true;
    private static boolean lastEnabled = false;
    private static int lastHash = 0;
    private static List<String> lastList = null;

    private XrayUtil() {
    }

    public static boolean isEnabled() {
        HackModule m = GuiClient.MODULES.byId(ModuleId.XRAY);
        return m != null && m.isEnabled();
    }

    public static void markDirty() {
        dirty = true;
    }

    public static void tick(MinecraftClient client) {
        boolean enabled = XrayUtil.isEnabled();
        if (!enabled) {
            if (lastEnabled) {
                XrayUtil.reload(client);
            }
            lastEnabled = false;
            ALLOWED.clear();
            dirty = true;
            lastHash = 0;
            lastList = null;
            return;
        }
        boolean changed = XrayUtil.refreshIfNeeded();
        if (!lastEnabled || changed) {
            XrayUtil.reload(client);
        }
        lastEnabled = true;
    }

    public static boolean shouldRender(BlockState state) {
        if (state == null) {
            return !XrayUtil.isEnabled();
        }
        if (!XrayUtil.isEnabled()) {
            return true;
        }
        return XrayUtil.isAllowed(state);
    }

    public static boolean isAllowed(BlockState state) {
        if (state == null) {
            return false;
        }
        XrayUtil.refreshIfNeeded();
        if (ALLOWED.isEmpty()) {
            return false;
        }
        String id = Registries.BLOCK.getId(state.getBlock()).toString();
        return ALLOWED.contains(id);
    }

    private static boolean refreshIfNeeded() {
        List<String> ids = GuiClient.CONFIG.xrayIds;
        int hash = XrayUtil.hashIds(ids);
        if (!dirty && ids == lastList && hash == lastHash) {
            return false;
        }
        ALLOWED.clear();
        if (ids != null) {
            for (String id : ids) {
                if (id == null || id.isBlank()) continue;
                ALLOWED.add(id.trim());
            }
        }
        dirty = false;
        lastHash = hash;
        lastList = ids;
        return true;
    }

    private static int hashIds(List<String> ids) {
        if (ids == null) {
            return 0;
        }
        int h = 1;
        for (String id : ids) {
            h = 31 * h + (id == null ? 0 : id.hashCode());
        }
        return h;
    }

    private static void reload(MinecraftClient client) {
        if (client == null || client.worldRenderer == null) {
            return;
        }
        client.worldRenderer.reload();
    }
}

