package me.Gui.gui.ui.widget;

import java.util.Objects;
import me.Gui.gui.ui.GuiFonts;
import me.Gui.gui.ui.render.Rounded;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class UiAlphaSlider {
    public int x;
    public int y;
    public int w;
    public int h;
    public String label;
    public float value;
    public boolean dragging = false;
    private int baseRgb = 0xFFFFFF;
    private final AlphaChanged onChange;

    public UiAlphaSlider(int x, int y, int w, int h, String label, int initialAlpha, AlphaChanged onChange) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.label = label == null ? "" : label;
        this.value = UiAlphaSlider.clamp01((float)initialAlpha / 255.0f);
        this.onChange = onChange;
    }

    public void setBounds(int x, int y, int w, int h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    public void setBaseColor(int rgb) {
        this.baseRgb = rgb & 0xFFFFFF;
    }

    public void syncAlpha(int alpha) {
        if (this.dragging) {
            return;
        }
        this.value = UiAlphaSlider.clamp01((float)alpha / 255.0f);
    }

    public void render(DrawContext ctx, int mx, int my, int bg, int textCol, int accent) {
        float r = Math.min((float)this.h * 0.45f, 8.0f);
        Rounded.rect(ctx, this.x, this.y, this.w, this.h, r, bg);
        int pad = 8;
        int barX = this.x + pad;
        int barW = Math.max(1, this.w - pad * 2);
        int barY1 = this.y + this.h - 8;
        int barY2 = this.y + this.h - 4;
        int barH = Math.max(1, barY2 - barY1);
        for (int i = 0; i < barW; ++i) {
            float t = barW <= 1 ? 0.0f : (float)i / (float)(barW - 1);
            int alpha = Math.max(10, Math.min(255, Math.round(t * 255.0f)));
            int color = alpha << 24 | this.baseRgb;
            ctx.fill(barX + i, barY1, barX + i + 1, barY1 + barH, color);
        }
        int knobX = barX + Math.round(this.value * (float)(barW - 1));
        int knobTop = barY1 - 2;
        int knobBot = barY1 + barH + 2;
        ctx.fill(knobX - 1, knobTop, knobX + 2, knobBot, -1);
        TextRenderer tr = GuiFonts.textRenderer();
        String msg = this.label.isBlank() ? this.alphaText() : this.label + ": " + this.alphaText();
        int lx = this.x + (int)Math.ceil(r) + 2;
        Objects.requireNonNull(tr);
        int ly = this.y + (this.h - 9) / 2;
        ctx.drawText(tr, (Text)Text.literal((String)msg), lx, ly, textCol, false);
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) {
            return false;
        }
        if (this.isHover((int)mx, (int)my)) {
            this.dragging = true;
            this.setFromMouse(mx);
            return true;
        }
        return false;
    }

    public void mouseReleased(double mx, double my, int button) {
        if (button == 0) {
            this.dragging = false;
        }
    }

    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button != 0 || !this.dragging) {
            return false;
        }
        this.setFromMouse(mx);
        return true;
    }

    private boolean isHover(int mx, int my) {
        return mx >= this.x && my >= this.y && mx < this.x + this.w && my < this.y + this.h;
    }

    private void setFromMouse(double mx) {
        double t = (mx - (double)(this.x + 8)) / (double)(this.w - 16);
        this.value = UiAlphaSlider.clamp01((float)t);
        if (this.onChange != null) {
            this.onChange.onChanged(Math.max(0, Math.min(255, Math.round(this.value * 255.0f))));
        }
    }

    private String alphaText() {
        int a = Math.max(0, Math.min(255, Math.round(this.value * 255.0f)));
        return Integer.toString(a);
    }

    private static float clamp01(float v) {
        return Math.max(0.0f, Math.min(1.0f, v));
    }

    public static interface AlphaChanged {
        public void onChanged(int var1);
    }
}

