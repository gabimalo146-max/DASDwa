package me.Gui.gui.ui.world;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.HashSet;
import java.util.List;
import me.Gui.gui.client.GuiClient;
import me.Gui.gui.modules.HackModule;
import me.Gui.gui.modules.ModuleId;
import me.Gui.gui.ui.Theme;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class ItemEspRenderer {
    private static final double SCAN_RADIUS = 48.0;
    private static final float FILL_ALPHA = 0.22f;
    private static final float OUTLINE_ALPHA = 0.9f;
    private static final float OUTLINE_THICKNESS = 0.02f;
    private static final double BOX_INFLATE = 0.02;
    private static final double MIN_THICKNESS = 0.02;

    private ItemEspRenderer() {
    }

    public static void render(WorldRenderContext context) {
        HackModule mod = GuiClient.MODULES.byId(ModuleId.ITEM_ESP);
        if (mod == null || !mod.isEnabled()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null) {
            return;
        }
        ClientWorld world = context.world();
        if (world == null) {
            return;
        }
        boolean addAll = GuiClient.CONFIG.itemEspAddAll != null && GuiClient.CONFIG.itemEspAddAll != false;
        HashSet<String> selected = null;
        if (!addAll) {
            List<String> ids = GuiClient.CONFIG.itemEspIds;
            if (ids == null || ids.isEmpty()) {
                return;
            }
            selected = new HashSet<String>();
            for (String id : ids) {
                if (id == null || id.isBlank()) continue;
                selected.add(id.trim());
            }
            if (selected.isEmpty()) {
                return;
            }
        }
        boolean drawFill = true;
        boolean drawOutline = false;
        if (context.camera() == null) {
            return;
        }
        Vec3d camPos = context.camera().getPos();
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d selfPos = client.player.getPos();
        double r = 48.0;
        Box area = new Box(selfPos.x - r, selfPos.y - r, selfPos.z - r, selfPos.x + r, selfPos.y + r, selfPos.z + r);
        List<ItemEntity> items = world.getEntitiesByClass(ItemEntity.class, area, e -> true);
        if (items.isEmpty()) {
            return;
        }
        int rgb = Theme.accentColor(System.currentTimeMillis()) & 0xFFFFFF;
        float red = (float)(rgb >>> 16 & 0xFF) / 255.0f;
        float green = (float)(rgb >>> 8 & 0xFF) / 255.0f;
        float blue = (float)(rgb & 0xFF) / 255.0f;
        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask((boolean)false);
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        float[] prevColor = RenderSystem.getShaderColor();
        RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = null;
        Matrix4f mat = matrices.peek().getPositionMatrix();
        for (ItemEntity item : items) {
            Box box;
            Identifier itemId;
            ItemStack stack;
            if (item == null || item.isRemoved() || !item.isAlive() || (stack = item.getStack()) == null || stack.isEmpty() || (itemId = Registries.ITEM.getId(stack.getItem())) == null) continue;
            String id = itemId.toString();
            if (!addAll && !selected.contains(id) || (box = item.getBoundingBox()) == null) continue;
            Box expanded = box.expand(0.02);
            Box fixed = ItemEspRenderer.ensureMinThickness(expanded);
            if (buf == null) {
                buf = tess.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
            }
            if (drawFill) {
                ItemEspRenderer.addBox(buf, mat, fixed.minX, fixed.minY, fixed.minZ, fixed.maxX, fixed.maxY, fixed.maxZ, red, green, blue, 0.22f);
            }
            if (!drawOutline) continue;
            ItemEspRenderer.drawOutlineBox(buf, mat, fixed.minX, fixed.minY, fixed.minZ, fixed.maxX, fixed.maxY, fixed.maxZ, 0.02f, red, green, blue, 0.9f);
        }
        if (buf != null) {
            BuiltBuffer built = buf.end();
            BufferRenderer.drawWithGlobalProgram((BuiltBuffer)built);
            built.close();
        }
        RenderSystem.setShaderColor((float)prevColor[0], (float)prevColor[1], (float)prevColor[2], (float)prevColor[3]);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.depthMask((boolean)true);
        RenderSystem.enableDepthTest();
        matrices.pop();
    }

    private static Box ensureMinThickness(Box box) {
        double minX = box.minX;
        double minY = box.minY;
        double minZ = box.minZ;
        double maxX = box.maxX;
        double maxY = box.maxY;
        double maxZ = box.maxZ;
        double dx = maxX - minX;
        double dy = maxY - minY;
        double dz = maxZ - minZ;
        if (dx < 0.02) {
            double cx = (minX + maxX) * 0.5;
            minX = cx - 0.01;
            maxX = cx + 0.01;
        }
        if (dy < 0.02) {
            double cy = (minY + maxY) * 0.5;
            minY = cy - 0.01;
            maxY = cy + 0.01;
        }
        if (dz < 0.02) {
            double cz = (minZ + maxZ) * 0.5;
            minZ = cz - 0.01;
            maxZ = cz + 0.01;
        }
        return new Box(minX, minY, minZ, maxX, maxY, maxZ);
    }

    private static void drawOutlineBox(BufferBuilder buf, Matrix4f mat, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float thickness, float r, float g, float b, float a) {
        double x1 = minX;
        double y1 = minY;
        double z1 = minZ;
        double x2 = maxX;
        double y2 = maxY;
        double z2 = maxZ;
        ItemEspRenderer.drawThickSegment(buf, mat, x1, y1, z1, x2, y1, z1, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x1, y1, z2, x2, y1, z2, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x1, y2, z1, x2, y2, z1, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x1, y2, z2, x2, y2, z2, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x1, y1, z1, x1, y2, z1, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x2, y1, z1, x2, y2, z1, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x1, y1, z2, x1, y2, z2, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x2, y1, z2, x2, y2, z2, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x1, y1, z1, x1, y1, z2, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x2, y1, z1, x2, y1, z2, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x1, y2, z1, x1, y2, z2, thickness, r, g, b, a);
        ItemEspRenderer.drawThickSegment(buf, mat, x2, y2, z1, x2, y2, z2, thickness, r, g, b, a);
    }

    private static void drawThickSegment(BufferBuilder buf, Matrix4f mat, double ax, double ay, double az, double bx, double by, double bz, float thickness, float r, float g, float b, float a) {
        double minX = Math.min(ax, bx) - (double)thickness;
        double minY = Math.min(ay, by) - (double)thickness;
        double minZ = Math.min(az, bz) - (double)thickness;
        double maxX = Math.max(ax, bx) + (double)thickness;
        double maxY = Math.max(ay, by) + (double)thickness;
        double maxZ = Math.max(az, bz) + (double)thickness;
        ItemEspRenderer.addBox(buf, mat, minX, minY, minZ, maxX, maxY, maxZ, r, g, b, a);
    }

    private static void addBox(BufferBuilder buf, Matrix4f mat, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float r, float g, float b, float a) {
        float x1 = (float)minX;
        float y1 = (float)minY;
        float z1 = (float)minZ;
        float x2 = (float)maxX;
        float y2 = (float)maxY;
        float z2 = (float)maxZ;
        ItemEspRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        ItemEspRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
    }

    private static void v(BufferBuilder buf, Matrix4f mat, float x, float y, float z, float r, float g, float b, float a) {
        buf.vertex(mat, x, y, z).color(r, g, b, a);
    }
}

