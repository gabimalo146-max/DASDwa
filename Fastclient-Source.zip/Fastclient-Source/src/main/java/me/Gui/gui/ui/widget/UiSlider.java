package me.Gui.gui.ui.widget;

import java.util.Objects;
import me.Gui.gui.ui.GuiFonts;
import me.Gui.gui.ui.render.Rounded;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class UiSlider {
    public int x;
    public int y;
    public int w;
    public int h;
    public Text label;
    public float value;
    public boolean dragging = false;
    private float renderValue;
    protected final ValueChanged onChange;

    public UiSlider(int x, int y, int w, int h, Text label, float initial01, ValueChanged onChange) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.label = label;
        this.renderValue = this.value = this.clamp01(initial01);
        this.onChange = onChange;
    }

    public void setBounds(int x, int y, int w, int h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    protected float clamp01(float v) {
        return Math.max(0.0f, Math.min(1.0f, v));
    }

    private float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private int lerpColor(int a, int b, float t) {
        if (t <= 0.0f) {
            return a;
        }
        if (t >= 1.0f) {
            return b;
        }
        int aA = a >>> 24 & 0xFF;
        int aR = a >>> 16 & 0xFF;
        int aG = a >>> 8 & 0xFF;
        int aB = a & 0xFF;
        int bA = b >>> 24 & 0xFF;
        int bR = b >>> 16 & 0xFF;
        int bG = b >>> 8 & 0xFF;
        int bB = b & 0xFF;
        int oA = (int)((float)aA + (float)(bA - aA) * t);
        int oR = (int)((float)aR + (float)(bR - aR) * t);
        int oG = (int)((float)aG + (float)(bG - aG) * t);
        int oB = (int)((float)aB + (float)(bB - aB) * t);
        return oA << 24 | oR << 16 | oG << 8 | oB;
    }

    public boolean isHover(int mx, int my) {
        return mx >= this.x && my >= this.y && mx < this.x + this.w && my < this.y + this.h;
    }

    public void render(DrawContext ctx, int mx, int my, int bg, int fill, int text) {
        String lbl;
        boolean hover = this.isHover(mx, my);
        if (this.dragging) {
            this.renderValue = this.value;
        } else {
            this.renderValue = this.lerp(this.renderValue, this.value, 0.25f);
            if (Math.abs(this.renderValue - this.value) < 0.001f) {
                this.renderValue = this.value;
            }
        }
        float r = Math.min((float)this.h * 0.45f, 8.0f);
        Rounded.rect(ctx, this.x, this.y, this.w, this.h, r, bg);
        int pad = 8;
        int barY1 = this.y + this.h - 7;
        int barY2 = this.y + this.h - 4;
        int barMax = Math.max(1, this.w - pad * 2);
        int barW = (int)(this.renderValue * (float)barMax);
        int barH = barY2 - barY1;
        int barR = Math.min(barH / 2, 3);
        Rounded.rect(ctx, this.x + pad, barY1, barW, barH, barR, fill);
        TextRenderer tr = GuiFonts.textRenderer();
        String string = lbl = this.label == null ? "" : this.label.getString();
        if (lbl != null && !lbl.isBlank()) {
            int lx = this.x + (int)Math.ceil(r) + 2;
            Objects.requireNonNull(tr);
            int ly = this.y + (this.h - 9) / 2;
            float t = this.dragging ? 1.0f : (hover ? 0.6f : 0.0f);
            int col = t > 0.0f ? this.lerpColor(text, fill, 0.55f * t) : text;
            ctx.drawText(tr, (Text)Text.literal((String)lbl), lx, ly, col, false);
        }
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) {
            return false;
        }
        if (this.isHover((int)mx, (int)my)) {
            this.dragging = true;
            this.setFromMouse(mx);
            return true;
        }
        return false;
    }

    public void mouseReleased(double mx, double my, int button) {
        if (button == 0) {
            this.dragging = false;
        }
    }

    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button != 0) {
            return false;
        }
        if (!this.dragging) {
            return false;
        }
        this.setFromMouse(mx);
        return true;
    }

    protected void setFromMouse(double mx) {
        double t = (mx - (double)(this.x + 8)) / (double)(this.w - 16);
        this.value = this.clamp01((float)t);
        if (this.onChange != null) {
            this.onChange.onChanged(this.value);
        }
    }

    public static interface ValueChanged {
        public void onChanged(float var1);
    }
}

