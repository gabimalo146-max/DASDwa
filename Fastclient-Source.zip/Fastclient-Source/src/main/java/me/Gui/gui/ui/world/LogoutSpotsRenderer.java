package me.Gui.gui.ui.world;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;
import me.Gui.gui.client.GuiClient;
import me.Gui.gui.config.GuiConfig;
import me.Gui.gui.mixin.LivingEntityRendererAccessor;
import me.Gui.gui.modules.HackModule;
import me.Gui.gui.modules.LogoutSpots;
import me.Gui.gui.modules.ModuleId;
import me.Gui.gui.ui.GuiFonts;
import me.Gui.gui.ui.Theme;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockRenderView;
import org.joml.Matrix4f;

public final class LogoutSpotsRenderer {
    private LogoutSpotsRenderer() {
    }

    public static void render(WorldRenderContext context) {
        HackModule mod = GuiClient.MODULES.byId(ModuleId.LOGOUT_SPOTS);
        if (mod == null || !mod.isEnabled()) {
            return;
        }
        Collection<LogoutSpots.Spot> spots = LogoutSpots.spots();
        if (spots.isEmpty()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return;
        }
        ClientWorld world = context.world();
        if (world == null) {
            return;
        }
        Camera camera = context.camera();
        if (camera == null) {
            return;
        }
        GuiConfig cfg = GuiClient.CONFIG;
        boolean showNick = cfg.logoutShowNick == null || cfg.logoutShowNick != false;
        boolean showTime = cfg.logoutShowTime == null || cfg.logoutShowTime != false;
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camPos = camera.getPos();
        VertexConsumerProvider.Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
        TextRenderer tr = GuiFonts.textRendererOrDefault(client.textRenderer);
        float[] prevColor = RenderSystem.getShaderColor();
        float gray = 0.75f;
        float alpha = 0.3f;
        float insideAlpha = 0.06f;
        int labelColor = Theme.withAlpha(Theme.accentColor(System.currentTimeMillis()), 255);
        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        long now = System.currentTimeMillis();
        for (LogoutSpots.Spot spot : spots) {
            String label;
            OtherClientPlayerEntity ghost = spot.ghost;
            if (ghost == null) continue;
            Vec3d pos = ghost.getPos();
            int light = WorldRenderer.getLightmapCoordinates((BlockRenderView)world, (BlockPos)BlockPos.ofFloored((Position)pos));
            float hoverBase = 0.06f;
            float bob = (float)Math.sin((double)(now - spot.logoutAtMs) / 350.0 + (double)(spot.uuid.hashCode() & 0xFF)) * 0.04f;
            float yOff = hoverBase + bob;
            boolean inside = LogoutSpotsRenderer.isInsideSpot(client, (PlayerEntity)ghost, camera.getPos());
            float ghostAlpha = inside ? insideAlpha : alpha;
            LogoutSpotsRenderer.renderSolidGhost(matrices, (PlayerEntity)ghost, pos, yOff, consumers, light, gray, ghostAlpha, spot.pose);
            RenderSystem.setShaderColor((float)prevColor[0], (float)prevColor[1], (float)prevColor[2], (float)prevColor[3]);
            if ((showNick || showTime) && !(label = LogoutSpotsRenderer.buildLabel(spot, showNick, showTime)).isBlank()) {
                Vec3d textPos = pos.add(0.0, (double)ghost.getHeight() + 0.55 + (double)yOff, 0.0);
                LogoutSpotsRenderer.drawLabel(matrices, camera, tr, consumers, textPos, label, labelColor);
            }
            Vec3d headPos = pos.add(0.28, (double)ghost.getHeight() * 1.02 + (double)yOff, 0.14);
            LogoutSpotsRenderer.drawSleepZzz(matrices, camera, tr, consumers, headPos, now - spot.logoutAtMs);
        }
        RenderSystem.setShaderColor((float)prevColor[0], (float)prevColor[1], (float)prevColor[2], (float)prevColor[3]);
        consumers.draw();
        RenderSystem.disableBlend();
        matrices.pop();
    }

    private static String buildLabel(LogoutSpots.Spot spot, boolean showNick, boolean showTime) {
        String time;
        String name = showNick ? LogoutSpotsRenderer.resolveDisplayName(spot.name) : "";
        String string = time = showTime ? LogoutSpotsRenderer.formatElapsed(spot.logoutAtMs) : "";
        if (name.isBlank()) {
            return time;
        }
        if (time.isBlank()) {
            return name;
        }
        return name + " " + time;
    }

    private static String resolveDisplayName(String name) {
        if (name == null) {
            return "";
        }
        String display = GuiClient.FRIENDS.getDisplayName(name);
        if (display != null && !display.isBlank()) {
            return display;
        }
        return name;
    }

    private static String formatElapsed(long startMs) {
        long now = System.currentTimeMillis();
        long sec = Math.max(0L, (now - startMs) / 1000L);
        long min = sec / 60L;
        long hrs = min / 60L;
        if (hrs > 0L) {
            long rm = min % 60L;
            return hrs + "h " + rm + "m";
        }
        if (min > 0L) {
            long rs = sec % 60L;
            return min + "m " + rs + "s";
        }
        return sec + "s";
    }

    private static void drawLabel(MatrixStack matrices, Camera camera, TextRenderer tr, VertexConsumerProvider.Immediate consumers, Vec3d pos, String text, int color) {
        matrices.push();
        matrices.translate(pos.x, pos.y, pos.z);
        matrices.multiply(camera.getRotation());
        Vec3d camPos = camera.getPos();
        double dist = camPos.distanceTo(pos);
        float scale = LogoutSpotsRenderer.clamp(0.015f + (float)dist * 4.0E-4f, 0.015f, 0.04f);
        matrices.scale(scale, -scale, scale);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        float x = (float)(-tr.getWidth(text)) / 2.0f;
        float pad = 3.0f;
        float w = tr.getWidth(text);
        Objects.requireNonNull(tr);
        float h = 9.0f;
        LogoutSpotsRenderer.drawLabelBackground(mat, x - pad, -pad, w + pad * 2.0f, h + pad * 2.0f, -805306368);
        int outline = -16777216;
        tr.draw(text, x - 1.0f, -1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x + 1.0f, -1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x - 1.0f, 1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x + 1.0f, 1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x - 1.0f, 0.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x + 1.0f, 0.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x, -1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x, 1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x, 0.0f, color, true, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        matrices.pop();
    }

    private static void drawLabelBackground(Matrix4f mat, float x, float y, float w, float h, int argb) {
        float r = (float)(argb >>> 16 & 0xFF) / 255.0f;
        float g = (float)(argb >>> 8 & 0xFF) / 255.0f;
        float b = (float)(argb & 0xFF) / 255.0f;
        float a = (float)(argb >>> 24 & 0xFF) / 255.0f;
        RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.disableDepthTest();
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        float x2 = x + w;
        float y2 = y + h;
        buf.vertex(mat, x, y, 0.0f).color(r, g, b, a);
        buf.vertex(mat, x2, y, 0.0f).color(r, g, b, a);
        buf.vertex(mat, x2, y2, 0.0f).color(r, g, b, a);
        buf.vertex(mat, x, y, 0.0f).color(r, g, b, a);
        buf.vertex(mat, x2, y2, 0.0f).color(r, g, b, a);
        buf.vertex(mat, x, y2, 0.0f).color(r, g, b, a);
        BuiltBuffer built = buf.end();
        BufferRenderer.drawWithGlobalProgram((BuiltBuffer)built);
        built.close();
        RenderSystem.enableDepthTest();
    }

    private static float clamp(float v, float a, float b) {
        return Math.max(a, Math.min(b, v));
    }

    private static boolean isInsideSpot(MinecraftClient client, PlayerEntity ghost, Vec3d camPos) {
        if (client == null || client.player == null || ghost == null || camPos == null) {
            return false;
        }
        Box box = ghost.getBoundingBox().expand(0.1);
        if (box.contains(camPos)) {
            return true;
        }
        return box.intersects(client.player.getBoundingBox());
    }

    private static void renderSolidGhost(MatrixStack matrices, PlayerEntity entity, Vec3d pos, float yOff, VertexConsumerProvider.Immediate consumers, int light, float gray, float alpha, LogoutSpots.PoseSnapshot pose) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return;
        }
        if (!(entity instanceof AbstractClientPlayerEntity)) {
            return;
        }
        AbstractClientPlayerEntity abstractClient = (AbstractClientPlayerEntity)entity;
        EntityRenderer entityRenderer = client.getEntityRenderDispatcher().getRenderer((Entity)abstractClient);
        if (!(entityRenderer instanceof PlayerEntityRenderer)) {
            return;
        }
        PlayerEntityRenderer renderer = (PlayerEntityRenderer)entityRenderer;
        PlayerEntityModel model = (PlayerEntityModel)renderer.getModel();
        PlayerEntityRenderState state = renderer.createRenderState();
        renderer.updateRenderState(abstractClient, state, 0.0f);
        model.setVisible(true);
        model.hat.visible = state.hatVisible;
        model.jacket.visible = state.jacketVisible;
        model.leftSleeve.visible = state.leftSleeveVisible;
        model.rightSleeve.visible = state.rightSleeveVisible;
        model.leftPants.visible = state.leftPantsLegVisible;
        model.rightPants.visible = state.rightPantsLegVisible;
        model.setAngles(state);
        if (pose != null) {
            model.head.pitch = pose.headPitch;
            model.head.yaw = pose.headYaw;
            model.head.roll = pose.headRoll;
            model.body.pitch = pose.bodyPitch;
            model.body.yaw = pose.bodyYaw;
            model.body.roll = pose.bodyRoll;
            model.rightArm.pitch = pose.rightArmPitch;
            model.rightArm.yaw = pose.rightArmYaw;
            model.rightArm.roll = pose.rightArmRoll;
            model.leftArm.pitch = pose.leftArmPitch;
            model.leftArm.yaw = pose.leftArmYaw;
            model.leftArm.roll = pose.leftArmRoll;
            model.rightLeg.pitch = pose.rightLegPitch;
            model.rightLeg.yaw = pose.rightLegYaw;
            model.rightLeg.roll = pose.rightLegRoll;
            model.leftLeg.pitch = pose.leftLegPitch;
            model.leftLeg.yaw = pose.leftLegYaw;
            model.leftLeg.roll = pose.leftLegRoll;
        }
        model.head.pitch = LogoutSpotsRenderer.clamp(model.head.pitch + 0.7f, -1.4f, 1.4f);
        model.head.roll = LogoutSpotsRenderer.clamp(model.head.roll + 0.25f, -1.0f, 1.0f);
        model.rightLeg.pitch = LogoutSpotsRenderer.clamp(model.rightLeg.pitch - 0.35f, -1.4f, 1.4f);
        model.leftLeg.pitch = LogoutSpotsRenderer.clamp(model.leftLeg.pitch - 0.35f, -1.4f, 1.4f);
        model.hat.pitch = model.head.pitch;
        model.hat.yaw = model.head.yaw;
        model.hat.roll = model.head.roll;
        Vec3d offset = renderer.getPositionOffset(state);
        matrices.push();
        matrices.translate(pos.x + offset.x, pos.y + (double)yOff + offset.y, pos.z + offset.z);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - state.yawDegrees));
        matrices.scale(state.baseScale, state.baseScale, state.baseScale);
        matrices.scale(-1.0f, -1.0f, 1.0f);
        matrices.translate(0.0f, -1.501f, 0.0f);
        RenderSystem.setShaderColor((float)gray, (float)gray, (float)gray, (float)alpha);
        Identifier texture = renderer.getTexture(state);
        RenderLayer layer = RenderLayer.getEntityTranslucent((Identifier)texture);
        TintedVertexConsumerProvider tinted = new TintedVertexConsumerProvider((VertexConsumerProvider)consumers, gray, gray, gray, 1.0f);
        model.render(matrices, tinted.getBuffer(layer), light, OverlayTexture.DEFAULT_UV);
        if (renderer instanceof LivingEntityRendererAccessor) {
            LivingEntityRendererAccessor accessor = (LivingEntityRendererAccessor)renderer;
            float limbSwing = state.limbFrequency;
            float limbSwingAmount = state.limbAmplitudeMultiplier;
            Iterator<FeatureRenderer<?, ?>> iterator = accessor.getFeatures().iterator();
            while (iterator.hasNext()) {
                FeatureRenderer feature;
                FeatureRenderer cast = feature = (FeatureRenderer)iterator.next();
                cast.render(matrices, (VertexConsumerProvider)tinted, light, (EntityRenderState)state, limbSwing, limbSwingAmount);
            }
        }
        matrices.pop();
    }

    private static void drawSleepZzz(MatrixStack matrices, Camera camera, TextRenderer tr, VertexConsumerProvider.Immediate consumers, Vec3d base, long ageMs) {
        float t = (float)(ageMs % 3200L) / 3200.0f;
        for (int i = 0; i < 3; ++i) {
            float phase = (t + (float)i * 0.33f) % 1.0f;
            float y = phase * 0.48f;
            float x = 0.04f + (float)i * 0.1f;
            float alpha = 0.65f + 0.35f * (1.0f - phase);
            int a = (int)(alpha * 220.0f);
            int col = a << 24 | 0xDDE9FF;
            Vec3d p = base.add((double)x, 0.1 + (double)y, 0.0);
            LogoutSpotsRenderer.drawTinyText(matrices, camera, tr, consumers, p, "z", 0.038f, col);
        }
    }

    private static void drawTinyText(MatrixStack matrices, Camera camera, TextRenderer tr, VertexConsumerProvider.Immediate consumers, Vec3d pos, String text, float scale, int color) {
        matrices.push();
        matrices.translate(pos.x, pos.y, pos.z);
        matrices.multiply(camera.getRotation());
        matrices.scale(scale, -scale, scale);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        float x = (float)(-tr.getWidth(text)) / 2.0f;
        RenderSystem.disableDepthTest();
        tr.draw(text, x, 0.0f, color, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        RenderSystem.enableDepthTest();
        matrices.pop();
    }

    private static final class TintedVertexConsumerProvider
    implements VertexConsumerProvider {
        private final VertexConsumerProvider delegate;
        private final float r;
        private final float g;
        private final float b;
        private final float a;

        private TintedVertexConsumerProvider(VertexConsumerProvider delegate, float r, float g, float b, float a) {
            this.delegate = delegate;
            this.r = r;
            this.g = g;
            this.b = b;
            this.a = a;
        }

        public VertexConsumer getBuffer(RenderLayer layer) {
            return new TintedVertexConsumer(this.delegate.getBuffer(layer), this.r, this.g, this.b, this.a);
        }
    }

    private static final class TintedVertexConsumer
    implements VertexConsumer {
        private final VertexConsumer delegate;
        private final float r;
        private final float g;
        private final float b;
        private final float a;

        private TintedVertexConsumer(VertexConsumer delegate, float r, float g, float b, float a) {
            this.delegate = delegate;
            this.r = r;
            this.g = g;
            this.b = b;
            this.a = a;
        }

        public VertexConsumer vertex(float x, float y, float z) {
            this.delegate.vertex(x, y, z);
            return this;
        }

        public VertexConsumer vertex(Matrix4f matrix, float x, float y, float z) {
            this.delegate.vertex(matrix, x, y, z);
            return this;
        }

        public VertexConsumer color(int red, int green, int blue, int alpha) {
            int l = (int)(0.299f * (float)red + 0.587f * (float)green + 0.114f * (float)blue);
            float s = 0.03f;
            int nr = Math.round((float)l + (float)(red - l) * s);
            int ng = Math.round((float)l + (float)(green - l) * s);
            int nb = Math.round((float)l + (float)(blue - l) * s);
            int na = Math.round((float)alpha * this.a);
            this.delegate.color(nr, ng, nb, na);
            return this;
        }

        public VertexConsumer color(float red, float green, float blue, float alpha) {
            float l = 0.299f * red + 0.587f * green + 0.114f * blue;
            float s = 0.03f;
            float nr = l + (red - l) * s;
            float ng = l + (green - l) * s;
            float nb = l + (blue - l) * s;
            this.delegate.color(nr, ng, nb, alpha * this.a);
            return this;
        }

        public VertexConsumer texture(float u, float v) {
            this.delegate.texture(u, v);
            return this;
        }

        public VertexConsumer overlay(int u, int v) {
            this.delegate.overlay(u, v);
            return this;
        }

        public VertexConsumer light(int u, int v) {
            this.delegate.light(u, v);
            return this;
        }

        public VertexConsumer normal(float x, float y, float z) {
            this.delegate.normal(x, y, z);
            return this;
        }
    }
}

