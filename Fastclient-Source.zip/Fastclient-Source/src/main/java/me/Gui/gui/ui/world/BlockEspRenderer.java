package me.Gui.gui.ui.world;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import me.Gui.gui.client.GuiClient;
import me.Gui.gui.modules.HackModule;
import me.Gui.gui.modules.ModuleId;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.BlockView;
import org.joml.Matrix4f;

public final class BlockEspRenderer {
    private static final int SCAN_RADIUS = 32;
    private static final long SCAN_INTERVAL_MS = 300L;
    private static final float FILL_ALPHA = 0.2f;
    private static final float OUTLINE_ALPHA = 0.65f;
    private static final float OUTLINE_THICKNESS = 0.02f;
    private static final double BOX_INFLATE = 0.004;
    private static final double MIN_THICKNESS = 0.02;
    private static final List<BlockSpot> CACHED = new ArrayList<BlockSpot>();
    private static long lastScanMs = 0L;
    private static BlockPos lastCenter = null;

    private BlockEspRenderer() {
    }

    public static void render(WorldRenderContext context) {
        HackModule mod = GuiClient.MODULES.byId(ModuleId.BLOCK_ESP);
        if (mod == null || !mod.isEnabled()) {
            BlockEspRenderer.invalidate();
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.world == null || client.player == null) {
            return;
        }
        if (!BlockEspRenderer.refreshCache(client, context.world())) {
            return;
        }
        if (CACHED.isEmpty()) {
            return;
        }
        Camera camera = context.camera();
        if (camera == null) {
            return;
        }
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camPos = camera.getPos();
        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask((boolean)false);
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        float[] prevColor = RenderSystem.getShaderColor();
        RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        for (BlockSpot spot : CACHED) {
            int rgb = spot.rgb;
            float r = (float)(rgb >>> 16 & 0xFF) / 255.0f;
            float g = (float)(rgb >>> 8 & 0xFF) / 255.0f;
            float b = (float)(rgb & 0xFF) / 255.0f;
            for (Box box : spot.boxes) {
                double eps = 0.001;
                double minX = box.minX - eps;
                double minY = box.minY - eps;
                double minZ = box.minZ - eps;
                double maxX = box.maxX + eps;
                double maxY = box.maxY + eps;
                double maxZ = box.maxZ + eps;
                BlockEspRenderer.addBox(buf, mat, minX, minY, minZ, maxX, maxY, maxZ, r, g, b, 0.2f);
                BlockEspRenderer.drawOutlineBox(buf, mat, minX, minY, minZ, maxX, maxY, maxZ, 0.02f, r, g, b, 0.65f);
            }
        }
        BuiltBuffer built = buf.end();
        BufferRenderer.drawWithGlobalProgram((BuiltBuffer)built);
        built.close();
        RenderSystem.setShaderColor((float)prevColor[0], (float)prevColor[1], (float)prevColor[2], (float)prevColor[3]);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.depthMask((boolean)true);
        RenderSystem.enableDepthTest();
        matrices.pop();
    }

    public static void invalidate() {
        lastScanMs = 0L;
        lastCenter = null;
        CACHED.clear();
    }

    private static boolean refreshCache(MinecraftClient client, ClientWorld world) {
        List<String> selected = GuiClient.CONFIG.blockEspIds;
        if (selected == null || selected.isEmpty()) {
            CACHED.clear();
            return false;
        }
        long now = System.currentTimeMillis();
        BlockPos center = client.player.getBlockPos();
        if (lastCenter != null && center.equals((Object)lastCenter) && now - lastScanMs < 300L) {
            return true;
        }
        lastScanMs = now;
        lastCenter = center;
        CACHED.clear();
        HashSet<String> selectedIds = new HashSet<String>();
        for (String id : selected) {
            BlockEspRenderer.addExpandedIds(selectedIds, id);
        }
        BlockColors colors = client.getBlockColors();
        ShapeContext playerCtx = ShapeContext.of((Entity)client.player);
        ShapeContext emptyCtx = ShapeContext.absent();
        BlockPos.Mutable pos = new BlockPos.Mutable();
        int r = 32;
        int minX = center.getX() - r;
        int maxX = center.getX() + r;
        int minY = Math.max(world.getBottomY(), center.getY() - r);
        int maxWorldY = world.getBottomY() + world.getHeight() - 1;
        int maxY = Math.min(maxWorldY, center.getY() + r);
        int minZ = center.getZ() - r;
        int maxZ = center.getZ() + r;
        for (int x = minX; x <= maxX; ++x) {
            for (int y = minY; y <= maxY; ++y) {
                for (int z = minZ; z <= maxZ; ++z) {
                    String id;
                    pos.set(x, y, z);
                    BlockState state = world.getBlockState((BlockPos)pos);
                    if (state.isAir() || !selectedIds.contains(id = Registries.BLOCK.getId(state.getBlock()).toString())) continue;
                    int rgb = BlockEspRenderer.resolveColor(colors, state, world, (BlockPos)pos);
                    List<Box> boxes = BlockEspRenderer.resolveBoxes(state, world, (BlockPos)pos, emptyCtx, playerCtx);
                    if (boxes.isEmpty()) continue;
                    CACHED.add(new BlockSpot(pos.toImmutable(), rgb, boxes));
                }
            }
        }
        return true;
    }

    private static void addExpandedIds(Set<String> out, String id) {
        if (id == null || id.isBlank()) {
            return;
        }
        String canonical = BlockEspRenderer.canonicalBlockId(id);
        BlockEspRenderer.addIfExists(out, canonical);
        int split = canonical.indexOf(58);
        String ns = split >= 0 ? canonical.substring(0, split + 1) : "";
        String path = split >= 0 ? canonical.substring(split + 1) : canonical;
        BlockEspRenderer.addIfExists(out, ns + "wall_" + path);
        String insert = BlockEspRenderer.insertWallVariant(path);
        if (insert != null && !insert.isBlank()) {
            BlockEspRenderer.addIfExists(out, ns + insert);
        }
    }

    private static String canonicalBlockId(String id) {
        String path;
        if (id == null) {
            return "";
        }
        int split = id.indexOf(58);
        String ns = split >= 0 ? id.substring(0, split + 1) : "";
        String canonicalPath = path = split >= 0 ? id.substring(split + 1) : id;
        if (path.startsWith("wall_")) {
            canonicalPath = path.substring("wall_".length());
        } else if (path.contains("_wall_")) {
            canonicalPath = path.replace("_wall_", "_");
        }
        return ns + canonicalPath;
    }

    private static String insertWallVariant(String path) {
        if (path == null || path.isBlank()) {
            return null;
        }
        if (path.endsWith("_hanging_sign")) {
            String base = path.substring(0, path.length() - "_hanging_sign".length());
            return base + "_wall_hanging_sign";
        }
        int last = path.lastIndexOf(95);
        if (last <= 0 || last == path.length() - 1) {
            return null;
        }
        return path.substring(0, last) + "_wall_" + path.substring(last + 1);
    }

    private static void addIfExists(Set<String> out, String id) {
        Identifier ident = Identifier.tryParse((String)id);
        if (ident != null && Registries.BLOCK.containsId(ident)) {
            out.add(id);
        }
    }

    private static int resolveColor(BlockColors colors, BlockState state, ClientWorld world, BlockPos pos) {
        int rgb = colors.getColor(state, (BlockRenderView)world, pos, 0);
        if (rgb == -1) {
            rgb = state.getMapColor((BlockView)world, (BlockPos)pos).color;
        }
        return rgb & 0xFFFFFF;
    }

    private static List<Box> resolveBoxes(BlockState state, ClientWorld world, BlockPos pos, ShapeContext primaryCtx, ShapeContext fallbackCtx) {
        VoxelShape shape = state.getOutlineShape((BlockView)world, pos, primaryCtx);
        if (shape.isEmpty()) {
            shape = state.getCollisionShape((BlockView)world, pos, primaryCtx);
        }
        if (shape.isEmpty() && fallbackCtx != null && (shape = state.getOutlineShape((BlockView)world, pos, fallbackCtx)).isEmpty()) {
            shape = state.getCollisionShape((BlockView)world, pos, fallbackCtx);
        }
        if (shape.isEmpty()) {
            return List.of();
        }
        ArrayList<Box> out = new ArrayList<Box>();
        for (Box box : shape.getBoundingBoxes()) {
            Box worldBox = box.offset(pos);
            double minX = worldBox.minX - 0.004;
            double minY = worldBox.minY - 0.004;
            double minZ = worldBox.minZ - 0.004;
            double maxX = worldBox.maxX + 0.004;
            double maxY = worldBox.maxY + 0.004;
            double maxZ = worldBox.maxZ + 0.004;
            double dx = maxX - minX;
            double dy = maxY - minY;
            double dz = maxZ - minZ;
            if (dx < 0.02) {
                double cx = (minX + maxX) * 0.5;
                minX = cx - 0.01;
                maxX = cx + 0.01;
            }
            if (dy < 0.02) {
                double cy = (minY + maxY) * 0.5;
                minY = cy - 0.01;
                maxY = cy + 0.01;
            }
            if (dz < 0.02) {
                double cz = (minZ + maxZ) * 0.5;
                minZ = cz - 0.01;
                maxZ = cz + 0.01;
            }
            out.add(new Box(minX, minY, minZ, maxX, maxY, maxZ));
        }
        return out;
    }

    private static void drawOutlineBox(BufferBuilder buf, Matrix4f mat, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float thickness, float r, float g, float b, float a) {
        double x1 = minX;
        double y1 = minY;
        double z1 = minZ;
        double x2 = maxX;
        double y2 = maxY;
        double z2 = maxZ;
        BlockEspRenderer.drawThickSegment(buf, mat, x1, y1, z1, x2, y1, z1, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x1, y1, z2, x2, y1, z2, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x1, y2, z1, x2, y2, z1, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x1, y2, z2, x2, y2, z2, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x1, y1, z1, x1, y2, z1, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x2, y1, z1, x2, y2, z1, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x1, y1, z2, x1, y2, z2, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x2, y1, z2, x2, y2, z2, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x1, y1, z1, x1, y1, z2, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x2, y1, z1, x2, y1, z2, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x1, y2, z1, x1, y2, z2, thickness, r, g, b, a);
        BlockEspRenderer.drawThickSegment(buf, mat, x2, y2, z1, x2, y2, z2, thickness, r, g, b, a);
    }

    private static void drawThickSegment(BufferBuilder buf, Matrix4f mat, double ax, double ay, double az, double bx, double by, double bz, float thickness, float r, float g, float b, float a) {
        double minX = Math.min(ax, bx) - (double)thickness;
        double minY = Math.min(ay, by) - (double)thickness;
        double minZ = Math.min(az, bz) - (double)thickness;
        double maxX = Math.max(ax, bx) + (double)thickness;
        double maxY = Math.max(ay, by) + (double)thickness;
        double maxZ = Math.max(az, bz) + (double)thickness;
        BlockEspRenderer.addBox(buf, mat, minX, minY, minZ, maxX, maxY, maxZ, r, g, b, a);
    }

    private static void addBox(BufferBuilder buf, Matrix4f mat, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float r, float g, float b, float a) {
        float x1 = (float)minX;
        float y1 = (float)minY;
        float z1 = (float)minZ;
        float x2 = (float)maxX;
        float y2 = (float)maxY;
        float z2 = (float)maxZ;
        BlockEspRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        BlockEspRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
    }

    private static void v(BufferBuilder buf, Matrix4f mat, float x, float y, float z, float r, float g, float b, float a) {
        buf.vertex(mat, x, y, z).color(r, g, b, a);
    }

    private record BlockSpot(BlockPos pos, int rgb, List<Box> boxes) {
    }
}

