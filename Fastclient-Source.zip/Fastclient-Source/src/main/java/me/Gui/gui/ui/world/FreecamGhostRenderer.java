package me.Gui.gui.ui.world;

import me.Gui.gui.modules.FreecamUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockRenderView;

public final class FreecamGhostRenderer {
    private FreecamGhostRenderer() {
    }

    public static void render(WorldRenderContext context) {
        if (!FreecamUtil.isActive()) {
            return;
        }
        OtherClientPlayerEntity ghost = FreecamUtil.ghost();
        if (ghost == null) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return;
        }
        ClientWorld world = context.world();
        if (world == null) {
            return;
        }
        Camera camera = context.camera();
        if (camera == null) {
            return;
        }
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camPos = camera.getPos();
        EntityRenderDispatcher dispatcher = client.getEntityRenderDispatcher();
        VertexConsumerProvider.Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);
        Vec3d pos = ghost.getPos();
        int light = WorldRenderer.getLightmapCoordinates((BlockRenderView)world, (BlockPos)BlockPos.ofFloored((Position)pos));
        dispatcher.render((Entity)ghost, pos.x, pos.y, pos.z, ghost.getYaw(), matrices, (VertexConsumerProvider)consumers, light);
        consumers.draw();
        matrices.pop();
    }
}

