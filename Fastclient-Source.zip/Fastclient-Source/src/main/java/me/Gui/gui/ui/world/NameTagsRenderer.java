package me.Gui.gui.ui.world;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.Gui.gui.client.GuiClient;
import me.Gui.gui.config.GuiConfig;
import me.Gui.gui.modules.HackModule;
import me.Gui.gui.modules.ModuleId;
import me.Gui.gui.modules.NameProtectUtil;
import me.Gui.gui.ui.GuiFonts;
import me.Gui.gui.ui.Theme;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Quaternionfc;
import org.joml.Vector3f;
import org.joml.Vector4f;

public final class NameTagsRenderer {
    private static final EquipmentSlot[] ARMOR_SLOTS = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
    private static final int ICON_SIZE = 16;
    private static final int ICON_SPACING = 18;
    private static final int EFFECT_SIZE = 14;
    private static final int EFFECT_SPACING = 16;
    private static final int ENCHANT_LINE_HEIGHT = 7;
    private static final int MAX_EFFECTS = 6;
    private static final int ROUND_RADIUS = 2;
    private static final int HEADER_BORDER_THICKNESS = 1;
    private static final int HEADER_TO_SET_GAP = 4;
    private static final int FIXED_WHITE_TEXT = -1;
    private static final int FIXED_DURABILITY_TRACK = -10066330;
    private static final float ENCHANT_TEXT_SCALE = 0.56f;
    private static final float MIN_ENCHANT_TEXT_SCALE = 0.38f;
    private static final float EFFECT_DURATION_SCALE = 0.62f;
    private static final float EFFECT_LEVEL_SCALE = 0.55f;
    private static final float ITEM_COUNT_SCALE = 1.0f;
    private static final int DURABILITY_BAR_WIDTH = 12;
    private static final int DURABILITY_BAR_HEIGHT = 1;
    private static final double WORLD_NAME_TAG_OFFSET = 0.3;
    private static final float SCREEN_CULL_MARGIN = 200.0f;
    private static final float OVERLAP_ALPHA_MULTIPLIER = 0.85f;
    private static final float SCREEN_SMOOTHING = 0.35f;
    private static final float BACKFACE_DOT_CUTOFF = 0.01f;
    private static final Pattern SET_BONUS_PATTERN = Pattern.compile("\\+\\s*([1-7])");
    private static final List<RenderEntry> ENTRIES = new ArrayList<RenderEntry>();
    private static final Map<String, String> ENCHANT_SHORT = NameTagsRenderer.createEnchantmentShortNames();
    private static final Map<UUID, SmoothedPoint> SMOOTHED = new HashMap<UUID, SmoothedPoint>();
    private static Vec3d lastCameraPos = null;
    private static float lastCameraYaw = 0.0f;
    private static float lastCameraPitch = 0.0f;
    private static boolean hasCameraState = false;
    private static boolean registered = false;

    private NameTagsRenderer() {
    }

    public static void register() {
        if (registered) {
            return;
        }
        registered = true;
        WorldRenderEvents.AFTER_ENTITIES.register(NameTagsRenderer::captureEntries);
        HudRenderCallback.EVENT.register(NameTagsRenderer::renderHud);
    }

    private static boolean isEnabled() {
        HackModule m = GuiClient.MODULES.byId(ModuleId.NAMETAGS);
        return m != null && m.isEnabled();
    }

    private static void captureEntries(WorldRenderContext context) {
        ENTRIES.clear();
        MinecraftClient client = MinecraftClient.getInstance();
        if (!NameTagsRenderer.isEnabled() || client.world == null || client.player == null) {
            return;
        }
        GuiConfig config = GuiClient.CONFIG;
        boolean allowSelf = NameTagsRenderer.bool(config.nametagsShowSelf, true);
        boolean firstPerson = client.options.getPerspective().isFirstPerson();
        Matrix4f positionMatrix = context.positionMatrix();
        Matrix4f projectionMatrix = context.projectionMatrix();
        if (positionMatrix == null || projectionMatrix == null) {
            return;
        }
        float tickDelta = context.tickCounter() == null ? 1.0f : context.tickCounter().getTickDelta(false);
        Vec3d selfPos = client.player.getLerpedPos(tickDelta);
        boolean hasContextCamera = context.camera() != null;
        Vec3d cameraPos = hasContextCamera ? context.camera().getPos() : client.gameRenderer.getCamera().getPos();
        float cameraYaw = hasContextCamera ? context.camera().getYaw() : client.gameRenderer.getCamera().getYaw();
        float cameraPitch = hasContextCamera ? context.camera().getPitch() : client.gameRenderer.getCamera().getPitch();
        Vector3f cameraForward = new Vector3f(0.0f, 0.0f, -1.0f);
        if (hasContextCamera) {
            cameraForward.rotate((Quaternionfc)context.camera().getRotation());
        } else {
            cameraForward.rotate((Quaternionfc)client.gameRenderer.getCamera().getRotation());
        }
        boolean useRelativeCoords = !NameTagsRenderer.isCameraAtOrigin(positionMatrix, cameraPos);
        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();
        float smoothingFactor = 0.35f;
        if (hasCameraState) {
            double moveDist = cameraPos.distanceTo(lastCameraPos);
            float yawDelta = Math.abs(MathHelper.wrapDegrees((float)(cameraYaw - lastCameraYaw)));
            float pitchDelta = Math.abs(cameraPitch - lastCameraPitch);
            if (moveDist > 0.02 || yawDelta > 0.6f || pitchDelta > 0.6f) {
                smoothingFactor = 1.0f;
            }
        }
        lastCameraPos = cameraPos;
        lastCameraYaw = cameraYaw;
        lastCameraPitch = cameraPitch;
        hasCameraState = true;
        double maxDistance = NameTagsRenderer.bool(config.nametagsShortenDistance, false) ? 64.0 : 512.0;
        HashSet<UUID> seen = new HashSet<UUID>();
        for (PlayerEntity target : client.world.getPlayers()) {
            if (!target.isAlive() || target.isRemoved() || target.isSpectator() || target == client.player && (!allowSelf || firstPerson)) continue;
            Vec3d targetPos = target.getLerpedPos(tickDelta);
            double distance = targetPos.distanceTo(selfPos);
            double dx = targetPos.x - selfPos.x;
            double dz = targetPos.z - selfPos.z;
            double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
            if (horizontalDistance > maxDistance) continue;
            Vec3d anchorWorld = targetPos.add(0.0, (double)target.getHeight() + 0.3, 0.0);
            Vec3d toAnchor = anchorWorld.subtract(cameraPos);
            if ((float)((double)cameraForward.x * toAnchor.x + (double)cameraForward.y * toAnchor.y + (double)cameraForward.z * toAnchor.z) < 0.01f) continue;
            ScreenPoint point = NameTagsRenderer.projectToScreen(anchorWorld, cameraPos, positionMatrix, projectionMatrix, screenWidth, screenHeight, useRelativeCoords);
            if (point == null && distance <= 4.0) {
                Vec3d closeAnchor = targetPos.add(0.0, (double)target.getHeight() * 0.65, 0.0);
                point = NameTagsRenderer.projectToScreen(closeAnchor, cameraPos, positionMatrix, projectionMatrix, screenWidth, screenHeight, useRelativeCoords);
            }
            if (point == null) {
                if (target != client.player || !allowSelf || firstPerson) continue;
                point = new ScreenPoint((float)screenWidth * 0.5f, (float)screenHeight * 0.4f);
            }
            if (point.x() < -200.0f || point.x() > (float)screenWidth + 200.0f || point.y() < -200.0f || point.y() > (float)screenHeight + 200.0f) continue;
            seen.add(target.getUuid());
            ScreenPoint smoothed = NameTagsRenderer.smoothScreenPoint(target.getUuid(), point, smoothingFactor);
            ENTRIES.add(new RenderEntry(target, smoothed.x(), smoothed.y(), distance));
        }
        SMOOTHED.keySet().removeIf(uuid -> !seen.contains(uuid));
        ENTRIES.sort(Comparator.comparingDouble(RenderEntry::distance).reversed());
    }

    private static void renderHud(DrawContext context, RenderTickCounter tickCounter) {
        if (ENTRIES.isEmpty()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (!NameTagsRenderer.isEnabled() || client.world == null || client.player == null) {
            ENTRIES.clear();
            return;
        }
        GuiConfig config = GuiClient.CONFIG;
        ArrayList<PreparedEntry> preparedEntries = new ArrayList<PreparedEntry>();
        int screenWidth = client.getWindow().getScaledWidth();
        int screenHeight = client.getWindow().getScaledHeight();
        for (RenderEntry entry : ENTRIES) {
            if (entry.player().isRemoved() || !entry.player().isAlive()) continue;
            TagLayout layout = NameTagsRenderer.buildLayout(client, entry, config, true);
            if (layout != null && layout.maxEnchantLines() > 0 && !NameTagsRenderer.enchantFitsOnScreen(layout, screenWidth, screenHeight)) {
                layout = NameTagsRenderer.buildLayout(client, entry, config, false);
            }
            if (layout == null) continue;
            preparedEntries.add(new PreparedEntry(entry, layout));
        }
        if (preparedEntries.isEmpty()) {
            return;
        }
        NameTagsRenderer.applyOverlapFading(preparedEntries);
        preparedEntries.sort(Comparator.comparingDouble((PreparedEntry value) -> value.entry().distance()).reversed());
        for (PreparedEntry prepared : preparedEntries) {
            NameTagsRenderer.renderTag(context, client, prepared, config);
        }
    }

    private static void renderTag(DrawContext context, MinecraftClient client, PreparedEntry prepared, GuiConfig config) {
        TagLayout layout = prepared.layout();
        TextRenderer textRenderer = GuiFonts.textRendererOrDefault(client.textRenderer);
        float alphaMultiplier = prepared.alphaMultiplier();
        int textColor = NameTagsRenderer.scaleAlpha(NameTagsRenderer.getTextColor(config), alphaMultiplier);
        int backgroundColor = NameTagsRenderer.scaleAlpha(NameTagsRenderer.getBackgroundColor(config), alphaMultiplier);
        int borderColor = NameTagsRenderer.scaleAlpha(NameTagsRenderer.getBorderColor(config), alphaMultiplier);
        if (GuiClient.FRIENDS.isFriend(prepared.entry().player().getName().getString())) {
            borderColor = NameTagsRenderer.scaleAlpha(-11151510, alphaMultiplier);
        }
        int overlayTextColor = NameTagsRenderer.scaleAlpha(-1, alphaMultiplier);
        int setBonusTextColor = NameTagsRenderer.scaleAlpha(Theme.accentColor(System.currentTimeMillis()), alphaMultiplier);
        int durabilityTrackColor = NameTagsRenderer.scaleAlpha(-10066330, alphaMultiplier);
        context.getMatrices().push();
        context.getMatrices().translate(layout.anchorX(), layout.anchorY(), 0.0f);
        context.getMatrices().scale(layout.scale(), layout.scale(), 1.0f);
        NameTagsRenderer.drawRoundedRect(context, layout.headerX1(), layout.headerY1(), layout.headerX2(), layout.headerY2(), backgroundColor, 2);
        NameTagsRenderer.drawRoundedBorder(context, layout.headerX1(), layout.headerY1(), layout.headerX2(), layout.headerY2(), borderColor, 2);
        context.drawTextWithShadow(textRenderer, layout.header(), layout.headerX(), 0, textColor);
        if (!layout.itemEntries().isEmpty()) {
            int itemStartX = -layout.itemWidth() / 2;
            NameTagsRenderer.renderItemIcons(context, textRenderer, layout.itemEntries(), itemStartX, layout.itemY(), NameTagsRenderer.bool(config.nametagsShowItemCount, true), overlayTextColor, alphaMultiplier);
            if (NameTagsRenderer.bool(config.nametagsShowEnchantments, true) && layout.maxEnchantLines() > 0) {
                NameTagsRenderer.renderItemEnchantments(context, textRenderer, layout.itemEntries(), itemStartX, layout.enchantTopY(), layout.maxEnchantLines(), overlayTextColor, setBonusTextColor);
            }
            if (NameTagsRenderer.bool(config.nametagsShowDurability, true)) {
                NameTagsRenderer.renderDurabilityBars(context, layout.itemEntries(), itemStartX, layout.durabilityY(), durabilityTrackColor, alphaMultiplier);
            }
        }
        if (!layout.effects().isEmpty()) {
            int effectsStartX = -layout.effectsWidth() / 2;
            NameTagsRenderer.renderEffects(context, client, textRenderer, layout.effects(), effectsStartX, layout.effectsY(), NameTagsRenderer.bool(config.nametagsShowEffects, true), overlayTextColor, alphaMultiplier);
        }
        context.getMatrices().pop();
    }

    private static TagLayout buildLayout(MinecraftClient client, RenderEntry entry, GuiConfig config, boolean allowEnchant) {
        int headerY2;
        PlayerEntity target = entry.player();
        TextRenderer textRenderer = GuiFonts.textRendererOrDefault(client.textRenderer);
        String header = NameTagsRenderer.buildHeaderLine(target, entry.distance(), config);
        if (header.isEmpty()) {
            return null;
        }
        List<ItemEntry> itemEntries = NameTagsRenderer.collectItemEntries(target, config);
        int maxEnchantLines = allowEnchant ? NameTagsRenderer.getMaxEnchantLines(itemEntries) : 0;
        List<StatusEffectInstance> effects = NameTagsRenderer.collectEffects(target, NameTagsRenderer.bool(config.nametagsShowEffects, true));
        int headerWidth = textRenderer.getWidth(header);
        int itemWidth = itemEntries.isEmpty() ? 0 : itemEntries.size() * 18 - 2;
        int effectsWidth = effects.isEmpty() ? 0 : effects.size() * 16 - 2;
        int headerY = 0;
        int topCursor = headerY - 2;
        int itemY = Integer.MIN_VALUE;
        if (!itemEntries.isEmpty()) {
            itemY = topCursor -= 20;
        }
        int enchantTopY = Integer.MIN_VALUE;
        if (!itemEntries.isEmpty() && NameTagsRenderer.bool(config.nametagsShowEnchantments, true) && maxEnchantLines > 0) {
            enchantTopY = topCursor -= maxEnchantLines * 7 + 1;
        }
        int effectsY = Integer.MIN_VALUE;
        if (!effects.isEmpty()) {
            effectsY = topCursor -= 18;
        }
        int durabilityY = Integer.MIN_VALUE;
        if (!itemEntries.isEmpty() && NameTagsRenderer.bool(config.nametagsShowDurability, true)) {
            durabilityY = itemY + 16;
        }
        float rawScale = NameTagsRenderer.computeScale(entry.distance()) * NameTagsRenderer.getGlobalScaleMultiplier(config);
        float scale = Math.max(0.65f, Math.min(2.5f, rawScale));
        float anchorX = entry.screenX();
        float anchorY = entry.screenY();
        int headerX = -headerWidth / 2;
        int headerX1 = headerX - 3;
        int headerY1 = headerY - 2;
        int headerX2 = headerX + headerWidth + 3;
        Objects.requireNonNull(textRenderer);
        int layoutBottom = headerY2 = headerY + 9 + 2;
        anchorY = Math.round(anchorY - (float)layoutBottom * scale);
        int minLocalX = headerX1;
        int maxLocalX = headerX2;
        if (!itemEntries.isEmpty()) {
            int itemStartX = -itemWidth / 2;
            minLocalX = Math.min(minLocalX, itemStartX);
            maxLocalX = Math.max(maxLocalX, itemStartX + itemWidth);
        }
        if (!effects.isEmpty()) {
            int effectsStartX = -effectsWidth / 2;
            minLocalX = Math.min(minLocalX, effectsStartX);
            maxLocalX = Math.max(maxLocalX, effectsStartX + effectsWidth);
        }
        int minLocalY = headerY1;
        int maxLocalY = headerY2;
        if (itemY != Integer.MIN_VALUE) {
            minLocalY = Math.min(minLocalY, itemY);
        }
        if (enchantTopY != Integer.MIN_VALUE) {
            minLocalY = Math.min(minLocalY, enchantTopY);
        }
        if (effectsY != Integer.MIN_VALUE) {
            minLocalY = Math.min(minLocalY, effectsY);
        }
        if (itemY != Integer.MIN_VALUE && NameTagsRenderer.bool(config.nametagsShowItemCount, true)) {
            Objects.requireNonNull(textRenderer);
            int countTop = Math.round((float)(itemY - 9) - 1.0f);
            minLocalY = Math.min(minLocalY, countTop);
        }
        if (durabilityY != Integer.MIN_VALUE) {
            maxLocalY = Math.max(maxLocalY, durabilityY + 1);
        }
        float boundsX1 = anchorX + (float)minLocalX * scale;
        float boundsX2 = anchorX + (float)maxLocalX * scale;
        float boundsY1 = anchorY + (float)minLocalY * scale;
        float boundsY2 = anchorY + (float)maxLocalY * scale;
        ScreenRect bounds = new ScreenRect(Math.min(boundsX1, boundsX2), Math.min(boundsY1, boundsY2), Math.max(boundsX1, boundsX2), Math.max(boundsY1, boundsY2));
        return new TagLayout(header, itemEntries, maxEnchantLines, effects, itemWidth, effectsWidth, itemY, enchantTopY, effectsY, durabilityY, headerX, headerX1, headerY1, headerX2, headerY2, scale, anchorX, anchorY, bounds);
    }

    private static void applyOverlapFading(List<PreparedEntry> preparedEntries) {
        ArrayList<PreparedEntry> nearFirst = new ArrayList<PreparedEntry>(preparedEntries);
        nearFirst.sort(Comparator.comparingDouble(value -> value.entry().distance()));
        ArrayList<ScreenRect> blockers = new ArrayList<ScreenRect>();
        for (PreparedEntry prepared : nearFirst) {
            boolean coveredByCloser = false;
            for (ScreenRect blocker : blockers) {
                if (!prepared.layout().bounds().intersects(blocker)) continue;
                coveredByCloser = true;
                break;
            }
            prepared.setAlphaMultiplier(coveredByCloser ? 0.85f : 1.0f);
            blockers.add(prepared.layout().bounds());
        }
    }

    private static int scaleAlpha(int color, float alphaMultiplier) {
        int alpha = color >>> 24;
        int scaled = Math.max(0, Math.min(255, Math.round((float)alpha * alphaMultiplier)));
        return scaled << 24 | color & 0xFFFFFF;
    }

    private static boolean enchantFitsOnScreen(TagLayout layout, int screenWidth, int screenHeight) {
        if (layout.enchantTopY() == Integer.MIN_VALUE || layout.maxEnchantLines() <= 0) {
            return true;
        }
        if (screenWidth <= 0 || screenHeight <= 0) {
            return true;
        }
        float top = layout.anchorY() + (float)layout.enchantTopY() * layout.scale();
        float bottom = layout.anchorY() + (float)(layout.enchantTopY() + layout.maxEnchantLines() * 7) * layout.scale();
        if (top < 0.0f || bottom > (float)screenHeight) {
            return false;
        }
        int itemWidth = layout.itemWidth();
        if (itemWidth <= 0) {
            return true;
        }
        int itemStartX = -itemWidth / 2;
        float left = layout.anchorX() + (float)itemStartX * layout.scale();
        float right = layout.anchorX() + (float)(itemStartX + itemWidth) * layout.scale();
        return left >= 0.0f && right <= (float)screenWidth;
    }

    private static void renderItemIcons(DrawContext context, TextRenderer textRenderer, List<ItemEntry> itemEntries, int startX, int y, boolean showCount, int countTextColor, float alphaMultiplier) {
        for (int i = 0; i < itemEntries.size(); ++i) {
            int overlayAlpha;
            int x = startX + i * 18;
            ItemEntry itemEntry = itemEntries.get(i);
            ItemStack stack = itemEntry.stack();
            if (stack.isEmpty()) continue;
            context.drawItemWithoutEntity(stack, x, y);
            if (alphaMultiplier < 0.999f && (overlayAlpha = Math.max(0, Math.min(170, Math.round((1.0f - alphaMultiplier) * 170.0f)))) > 0) {
                context.fill(x, y, x + 16, y + 16, overlayAlpha << 24);
            }
            if (!showCount || !itemEntry.handItem() || stack.getCount() <= 1) continue;
            NameTagsRenderer.drawItemCountOverlay(context, textRenderer, x, y, stack.getCount(), countTextColor);
        }
    }

    private static void renderItemEnchantments(DrawContext context, TextRenderer textRenderer, List<ItemEntry> itemEntries, int startX, int enchantTopY, int maxEnchantLines, int textColor, int setBonusColor) {
        for (int i = 0; i < itemEntries.size(); ++i) {
            int x = startX + i * 18;
            List<String> lines = itemEntries.get(i).enchantLines();
            if (lines.isEmpty()) continue;
            int lineBaseY = enchantTopY + (maxEnchantLines - lines.size()) * 7;
            for (int lineIndex = 0; lineIndex < lines.size(); ++lineIndex) {
                String line = lines.get(lineIndex);
                int y = lineBaseY + lineIndex * 7;
                float scale = NameTagsRenderer.computeEnchantScale(textRenderer, line);
                int lineColor = NameTagsRenderer.isSetBonusLine(line) ? setBonusColor : textColor;
                NameTagsRenderer.drawScaledCenteredText(context, textRenderer, line, (float)x + 8.0f, y, lineColor, scale);
            }
        }
    }

    private static void renderDurabilityBars(DrawContext context, List<ItemEntry> itemEntries, int startX, int y, int trackColor, float alphaMultiplier) {
        for (int i = 0; i < itemEntries.size(); ++i) {
            ItemEntry entry = itemEntries.get(i);
            ItemStack stack = entry.stack();
            if (stack.isEmpty() || !stack.isDamageable()) continue;
            int x = startX + i * 18 + 2;
            NameTagsRenderer.drawDurabilityBar(context, stack, x, y, 12, 1, trackColor, alphaMultiplier);
        }
    }

    private static void renderEffects(DrawContext context, MinecraftClient client, TextRenderer textRenderer, List<StatusEffectInstance> effects, int startX, int y, boolean showDuration, int textColor, float alphaMultiplier) {
        for (int i = 0; i < effects.size(); ++i) {
            String roman;
            int overlayAlpha;
            StatusEffectInstance effect = effects.get(i);
            int x = startX + i * 16;
            context.drawSpriteStretched(RenderLayer::getGuiTextured, client.getStatusEffectSpriteManager().getSprite(effect.getEffectType()), x + 1, y + 1, 12, 12);
            if (alphaMultiplier < 0.999f && (overlayAlpha = Math.max(0, Math.min(160, Math.round((1.0f - alphaMultiplier) * 160.0f)))) > 0) {
                context.fill(x + 1, y + 1, x + 14 - 1, y + 14 - 1, overlayAlpha << 24);
            }
            if (!(roman = NameTagsRenderer.toRoman(effect.getAmplifier() + 1)).isBlank()) {
                float scale = 0.55f;
                int textWidth = textRenderer.getWidth(roman);
                float pad = 1.0f;
                float drawX = (float)(x + 14) - pad - (float)textWidth * scale;
                float drawY = (float)y + pad;
                NameTagsRenderer.drawScaledText(context, textRenderer, roman, drawX, drawY, textColor, scale);
            }
            if (!showDuration) continue;
            String duration = NameTagsRenderer.formatEffectDuration(effect);
            float textY = y + 14 - 5;
            NameTagsRenderer.drawScaledCenteredText(context, textRenderer, duration, (float)x + 7.0f, textY, textColor, 0.62f);
        }
    }

    private static void drawDurabilityBar(DrawContext context, ItemStack stack, int x, int y, int width, int height, int trackColor, float alphaMultiplier) {
        if (stack.isEmpty()) {
            return;
        }
        float ratio = stack.isDamageable() && stack.getMaxDamage() > 0 ? (float)(stack.getMaxDamage() - stack.getDamage()) / (float)stack.getMaxDamage() : 1.0f;
        if ((ratio = Math.max(0.0f, Math.min(1.0f, ratio))) >= 0.999f) {
            return;
        }
        context.fill(x, y, x + width, y + height, trackColor);
        int filled = Math.max(0, Math.min(width, Math.round((float)width * ratio)));
        int color = NameTagsRenderer.scaleAlpha(0xFF000000 | MathHelper.hsvToRgb((float)(ratio / 3.0f), (float)1.0f, (float)1.0f), alphaMultiplier);
        if (filled > 0) {
            context.fill(x, y, x + filled, y + height, color);
        }
    }

    private static void drawItemCountOverlay(DrawContext context, TextRenderer textRenderer, int iconX, int iconY, int count, int textColor) {
        String value = Integer.toString(count);
        float scale = 1.0f;
        int textWidth = textRenderer.getWidth(value);
        float x = (float)iconX + (float)(16 - textWidth) / 2.0f;
        Objects.requireNonNull(textRenderer);
        float y = (float)(iconY - 9) - 1.0f;
        context.getMatrices().push();
        float snappedX = Math.round(x);
        float snappedY = Math.round(y);
        context.getMatrices().translate(snappedX, snappedY, 0.0f);
        context.getMatrices().scale(scale, scale, 1.0f);
        context.drawTextWithShadow(textRenderer, value, 0, 0, textColor);
        context.getMatrices().pop();
    }

    private static void drawScaledCenteredText(DrawContext context, TextRenderer textRenderer, String text, float centerX, float y, int color, float scale) {
        context.getMatrices().push();
        float snappedX = (float)Math.round(centerX * 2.0f) / 2.0f;
        float snappedY = (float)Math.round(y * 2.0f) / 2.0f;
        context.getMatrices().translate(snappedX, snappedY, 0.0f);
        context.getMatrices().scale(scale, scale, 1.0f);
        int drawX = Math.round((float)(-textRenderer.getWidth(text)) / 2.0f);
        context.drawTextWithShadow(textRenderer, text, drawX, 0, color);
        context.getMatrices().pop();
    }

    private static void drawScaledText(DrawContext context, TextRenderer textRenderer, String text, float x, float y, int color, float scale) {
        context.getMatrices().push();
        float snappedX = (float)Math.round(x * 2.0f) / 2.0f;
        float snappedY = (float)Math.round(y * 2.0f) / 2.0f;
        context.getMatrices().translate(snappedX, snappedY, 0.0f);
        context.getMatrices().scale(scale, scale, 1.0f);
        context.drawTextWithShadow(textRenderer, text, 0, 0, color);
        context.getMatrices().pop();
    }

    private static String buildHeaderLine(PlayerEntity player, double distance, GuiConfig config) {
        ArrayList<String> parts = new ArrayList<String>();
        String name = NameTagsRenderer.resolveDisplayName(player);
        if (NameTagsRenderer.bool(config.nametagsShowName, true)) {
            parts.add(name);
        }
        if (NameTagsRenderer.bool(config.nametagsShowDistance, true)) {
            parts.add(NameTagsRenderer.formatDistance(distance, NameTagsRenderer.bool(config.nametagsShortenDistance, false)));
        }
        if (NameTagsRenderer.bool(config.nametagsShowHealth, true)) {
            float health = player.getHealth() + player.getAbsorptionAmount();
            parts.add(String.format(Locale.US, "%.1fHP", Float.valueOf(health)));
        }
        if (parts.isEmpty()) {
            return name;
        }
        return String.join((CharSequence)" | ", parts);
    }

    private static String resolveDisplayName(PlayerEntity player) {
        String base = player.getName().getString();
        String protectedName = NameProtectUtil.getDisplayName(player);
        if (protectedName != null && !protectedName.isBlank()) {
            return protectedName;
        }
        String display = GuiClient.FRIENDS.getDisplayName(base);
        if (display != null && !display.isBlank()) {
            return display;
        }
        return base;
    }

    private static List<ItemEntry> collectItemEntries(PlayerEntity player, GuiConfig config) {
        boolean includeLines;
        ArrayList<ItemEntry> result = new ArrayList<ItemEntry>(6);
        boolean showEnchantments = NameTagsRenderer.bool(config.nametagsShowEnchantments, true);
        boolean showSetBonus = NameTagsRenderer.bool(config.nametagsShowSetBonus, true);
        boolean showHand = NameTagsRenderer.bool(config.nametagsShowHandItems, true);
        boolean showArmor = NameTagsRenderer.bool(config.nametagsShowArmorSet, true);
        boolean bl = includeLines = showEnchantments || showSetBonus;
        if (showHand) {
            ItemStack mainHand = player.getMainHandStack();
            result.add(new ItemEntry((ItemStack)mainHand, includeLines ? NameTagsRenderer.buildEnchantmentLines((ItemStack)mainHand, showEnchantments, showSetBonus) : List.of(), false, true));
        }
        if (showArmor) {
            for (EquipmentSlot slot : ARMOR_SLOTS) {
                ItemStack stack = player.getEquippedStack(slot);
                result.add(new ItemEntry(stack, includeLines ? NameTagsRenderer.buildEnchantmentLines(stack, showEnchantments, showSetBonus) : List.of(), true, false));
            }
        }
        if (showHand) {
            ItemStack offHand = player.getOffHandStack();
            result.add(new ItemEntry(offHand, includeLines ? NameTagsRenderer.buildEnchantmentLines(offHand, showEnchantments, showSetBonus) : List.of(), false, true));
        }
        return result;
    }

    private static int getMaxEnchantLines(List<ItemEntry> itemEntries) {
        int max = 0;
        for (ItemEntry entry : itemEntries) {
            max = Math.max(max, entry.enchantLines().size());
        }
        return max;
    }

    private static List<StatusEffectInstance> collectEffects(PlayerEntity player, boolean showEffects) {
        if (!showEffects) {
            return List.of();
        }
        ArrayList<StatusEffectInstance> effects = new ArrayList<>(player.getStatusEffects());
        effects.sort(Comparator.comparingInt(StatusEffectInstance::getDuration).reversed());
        if (effects.size() > 6) {
            effects = new ArrayList(effects.subList(0, 6));
        }
        return effects;
    }

    private static List<String> buildEnchantmentLines(ItemStack stack, boolean includeEnchantments, boolean includeSetBonus) {
        int bonus;
        if (stack.isEmpty()) {
            return List.of();
        }
        ArrayList<String> result = new ArrayList<String>();
        if (includeSetBonus && (bonus = NameTagsRenderer.extractSetBonus(stack)) > 0) {
            result.add("+" + bonus);
        }
        if (includeEnchantments) {
            ArrayList<EnchantLine> lines = new ArrayList<EnchantLine>();
            ItemEnchantmentsComponent ench = EnchantmentHelper.getEnchantments((ItemStack)stack);
            if (ench != null) {
                for (RegistryEntry<Enchantment> entry : ench.getEnchantments()) {
                    String key = entry.getKey().map(registryKey -> registryKey.getValue().getPath()).orElse("");
                    if (key.isEmpty()) {
                        key = entry.toString();
                    }
                    String shortName = NameTagsRenderer.shortenEnchantmentName(key);
                    lines.add(new EnchantLine(shortName, ench.getLevel(entry)));
                }
            }
            if (!lines.isEmpty()) {
                lines.sort(Comparator.comparingInt(EnchantLine::level).reversed().thenComparing(EnchantLine::name));
                for (EnchantLine line : lines) {
                    result.add(line.name() + " " + line.level());
                }
            }
        }
        return result.isEmpty() ? List.of() : result;
    }

    private static int extractSetBonus(ItemStack stack) {
        if (stack.isEmpty() || NameTagsRenderer.isLeatherArmor(stack)) {
            return 0;
        }
        int bonus = NameTagsRenderer.parseSetBonus(stack.getName().getString());
        if (bonus > 0) {
            return bonus;
        }
        LoreComponent lore = (LoreComponent)stack.get(DataComponentTypes.LORE);
        if (lore != null) {
            for (Text line : lore.lines()) {
                bonus = NameTagsRenderer.parseSetBonus(line.getString());
                if (bonus <= 0) continue;
                return bonus;
            }
        }
        return 0;
    }

    private static boolean isLeatherArmor(ItemStack stack) {
        return stack.isOf(Items.LEATHER_HELMET) || stack.isOf(Items.LEATHER_CHESTPLATE) || stack.isOf(Items.LEATHER_LEGGINGS) || stack.isOf(Items.LEATHER_BOOTS);
    }

    private static int parseSetBonus(String text) {
        if (text == null || text.isBlank()) {
            return 0;
        }
        Matcher matcher = SET_BONUS_PATTERN.matcher(text.trim());
        int best = 0;
        while (matcher.find()) {
            try {
                int value = Integer.parseInt(matcher.group(1));
                if (value <= best) continue;
                best = value;
            }
            catch (NumberFormatException numberFormatException) {}
        }
        return best;
    }

    private static boolean isSetBonusLine(String text) {
        return text != null && text.startsWith("+");
    }

    private static String shortenEnchantmentName(String idPath) {
        String mapped = ENCHANT_SHORT.get(idPath);
        if (mapped != null) {
            return mapped;
        }
        String normalized = idPath.replace("minecraft:", "");
        if (normalized.contains("_")) {
            StringBuilder builder = new StringBuilder();
            for (String piece : normalized.split("_")) {
                if (piece.isEmpty()) continue;
                builder.append(Character.toUpperCase(piece.charAt(0)));
            }
            if (builder.length() > 0) {
                return builder.toString();
            }
        }
        if (normalized.length() <= 4) {
            return normalized.toUpperCase(Locale.ROOT);
        }
        return normalized.substring(0, 4).toUpperCase(Locale.ROOT);
    }

    private static String formatDistance(double distance, boolean shortenDistance) {
        long meters = Math.max(0L, Math.round(distance));
        return meters + "m";
    }

    private static String formatEffectDuration(StatusEffectInstance effect) {
        if (effect.isInfinite()) {
            return "INF";
        }
        int seconds = Math.max(0, effect.getDuration() / 20);
        int minutes = seconds / 60;
        int remainder = seconds % 60;
        if (minutes > 0) {
            return minutes + ":" + String.format(Locale.US, "%02d", remainder);
        }
        return Integer.toString(seconds);
    }

    private static String toRoman(int value) {
        if (value <= 0) {
            return "";
        }
        if (value > 3999) {
            return Integer.toString(value);
        }
        int[] values = new int[]{1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] symbols = new String[]{"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        StringBuilder out = new StringBuilder();
        int remaining = value;
        for (int i = 0; i < values.length; ++i) {
            while (remaining >= values[i]) {
                out.append(symbols[i]);
                remaining -= values[i];
            }
        }
        return out.toString();
    }

    private static float computeEnchantScale(TextRenderer textRenderer, String text) {
        int width = Math.max(1, textRenderer.getWidth(text));
        float targetWidth = 16.0f;
        float fitScale = targetWidth / (float)width;
        return Math.max(0.38f, Math.min(0.56f, fitScale));
    }

    private static void drawRoundedRect(DrawContext context, int x1, int y1, int x2, int y2, int color, int radius) {
        int safeRadius = Math.max(1, Math.min(radius, Math.min((x2 - x1) / 2, (y2 - y1) / 2)));
        context.fill(x1 + safeRadius, y1, x2 - safeRadius, y1 + safeRadius, color);
        context.fill(x1, y1 + safeRadius, x2, y2 - safeRadius, color);
        context.fill(x1 + safeRadius, y2 - safeRadius, x2 - safeRadius, y2, color);
        context.fill(x1 + 1, y1 + 1, x1 + safeRadius, y1 + safeRadius, color);
        context.fill(x2 - safeRadius, y1 + 1, x2 - 1, y1 + safeRadius, color);
        context.fill(x1 + 1, y2 - safeRadius, x1 + safeRadius, y2 - 1, color);
        context.fill(x2 - safeRadius, y2 - safeRadius, x2 - 1, y2 - 1, color);
    }

    private static void drawRoundedBorder(DrawContext context, int x1, int y1, int x2, int y2, int color, int radius) {
        for (int layer = 0; layer < 1; ++layer) {
            int lx1 = x1 + layer;
            int ly1 = y1 + layer;
            int lx2 = x2 - layer;
            int ly2 = y2 - layer;
            if (lx2 - lx1 < 3 || ly2 - ly1 < 3) break;
            int safeRadius = Math.max(1, Math.min(Math.max(1, radius - layer), Math.min((lx2 - lx1) / 2, (ly2 - ly1) / 2)));
            context.fill(lx1 + safeRadius, ly1, lx2 - safeRadius, ly1 + 1, color);
            context.fill(lx1 + safeRadius, ly2 - 1, lx2 - safeRadius, ly2, color);
            context.fill(lx1, ly1 + safeRadius, lx1 + 1, ly2 - safeRadius, color);
            context.fill(lx2 - 1, ly1 + safeRadius, lx2, ly2 - safeRadius, color);
            context.fill(lx1 + 1, ly1 + 1, lx1 + 2, ly1 + 2, color);
            context.fill(lx2 - 2, ly1 + 1, lx2 - 1, ly1 + 2, color);
            context.fill(lx1 + 1, ly2 - 2, lx1 + 2, ly2 - 1, color);
            context.fill(lx2 - 2, ly2 - 2, lx2 - 1, ly2 - 1, color);
        }
    }

    private static float computeScale(double distance) {
        double maxBoost = 0.06;
        double boost = Math.min(maxBoost, distance / 200.0 * maxBoost);
        return (float)(1.0 + boost);
    }

    private static ScreenPoint projectToScreen(Vec3d worldPos, Vec3d cameraPos, Matrix4f positionMatrix, Matrix4f projectionMatrix, int screenWidth, int screenHeight, boolean useRelativeCoords) {
        Vec3d primary = useRelativeCoords ? worldPos.subtract(cameraPos) : worldPos;
        ScreenPoint direct = NameTagsRenderer.projectVectorToScreen((float)primary.x, (float)primary.y, (float)primary.z, positionMatrix, projectionMatrix, screenWidth, screenHeight);
        if (direct != null) {
            return direct;
        }
        Vec3d fallback = useRelativeCoords ? worldPos : worldPos.subtract(cameraPos);
        return NameTagsRenderer.projectVectorToScreen((float)fallback.x, (float)fallback.y, (float)fallback.z, positionMatrix, projectionMatrix, screenWidth, screenHeight);
    }

    private static ScreenPoint projectVectorToScreen(float x, float y, float z, Matrix4f positionMatrix, Matrix4f projectionMatrix, int screenWidth, int screenHeight) {
        Vector4f clip = new Vector4f(x, y, z, 1.0f);
        clip.mul((Matrix4fc)positionMatrix);
        clip.mul((Matrix4fc)projectionMatrix);
        if (clip.w <= 0.0f) {
            return null;
        }
        float ndcX = clip.x / clip.w;
        float ndcY = clip.y / clip.w;
        float ndcZ = clip.z / clip.w;
        if (ndcZ < -1.0f) {
            return null;
        }
        float screenX = (ndcX * 0.5f + 0.5f) * (float)screenWidth;
        float screenY = (1.0f - (ndcY * 0.5f + 0.5f)) * (float)screenHeight;
        if (!Float.isFinite(screenX) || !Float.isFinite(screenY)) {
            return null;
        }
        return new ScreenPoint(screenX, screenY);
    }

    private static boolean isCameraAtOrigin(Matrix4f positionMatrix, Vec3d cameraPos) {
        Vector4f test = new Vector4f((float)cameraPos.x, (float)cameraPos.y, (float)cameraPos.z, 1.0f);
        test.mul((Matrix4fc)positionMatrix);
        float epsilon = 0.001f;
        return Math.abs(test.x) < epsilon && Math.abs(test.y) < epsilon && Math.abs(test.z) < epsilon;
    }

    private static Map<String, String> createEnchantmentShortNames() {
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("protection", "PROT");
        map.put("fire_protection", "FPRO");
        map.put("blast_protection", "BPRO");
        map.put("projectile_protection", "PPRO");
        map.put("thorns", "THRN");
        map.put("unbreaking", "UNB");
        map.put("mending", "MEND");
        map.put("respiration", "RESP");
        map.put("aqua_affinity", "AQUA");
        map.put("feather_falling", "FF");
        map.put("depth_strider", "DEP");
        map.put("soul_speed", "SOUL");
        map.put("swift_sneak", "SWFT");
        map.put("efficiency", "EFF");
        map.put("fortune", "FORT");
        map.put("silk_touch", "SILK");
        map.put("sharpness", "SHARP");
        map.put("smite", "SMITE");
        map.put("bane_of_arthropods", "BOA");
        map.put("sweeping_edge", "SWEP");
        map.put("knockback", "KB");
        map.put("fire_aspect", "FASP");
        map.put("looting", "LOOT");
        map.put("power", "POW");
        map.put("punch", "PCH");
        map.put("flame", "FLM");
        map.put("infinity", "INF");
        map.put("multishot", "MULTI");
        map.put("piercing", "PRC");
        map.put("quick_charge", "QCH");
        map.put("loyalty", "LOY");
        map.put("impaling", "IMP");
        map.put("riptide", "RIP");
        map.put("channeling", "CHAN");
        map.put("density", "DENS");
        map.put("breach", "BRCH");
        map.put("wind_burst", "WIND");
        map.put("vanishing_curse", "COV");
        return map;
    }

    private static ScreenPoint smoothScreenPoint(UUID id, ScreenPoint raw, float smoothing) {
        SmoothedPoint existing = SMOOTHED.get(id);
        float t = Math.max(0.0f, Math.min(1.0f, smoothing));
        if (t >= 0.999f) {
            if (existing == null) {
                SMOOTHED.put(id, new SmoothedPoint(raw.x(), raw.y()));
            } else {
                existing.x = raw.x();
                existing.y = raw.y();
            }
            return raw;
        }
        if (existing == null) {
            SmoothedPoint created = new SmoothedPoint(raw.x(), raw.y());
            SMOOTHED.put(id, created);
            return raw;
        }
        existing.x += (raw.x() - existing.x) * t;
        existing.y += (raw.y() - existing.y) * t;
        return new ScreenPoint(existing.x, existing.y);
    }

    private static int getTextColor(GuiConfig cfg) {
        int rgb = cfg.nametagsTextColor & 0xFFFFFF;
        int alpha = NameTagsRenderer.clamp(cfg.nametagsTextAlpha, 0, 255);
        return alpha << 24 | rgb;
    }

    private static int getBackgroundColor(GuiConfig cfg) {
        int rgb = cfg.nametagsBackgroundColor & 0xFFFFFF;
        int alpha = NameTagsRenderer.clamp(cfg.nametagsBackgroundAlpha, 0, 255);
        return alpha << 24 | rgb;
    }

    private static int getBorderColor(GuiConfig cfg) {
        int rgb = cfg.nametagsBorderColor & 0xFFFFFF;
        int alpha = NameTagsRenderer.clamp(cfg.nametagsBackgroundAlpha, 0, 255);
        return alpha << 24 | rgb;
    }

    private static float getGlobalScaleMultiplier(GuiConfig cfg) {
        int v = NameTagsRenderer.clamp(cfg.nametagsScalePercent, 50, 200);
        return (float)v / 100.0f;
    }

    private static boolean bool(Boolean v, boolean def) {
        return v == null ? def : v;
    }

    private static int clamp(int v, int a, int b) {
        return Math.max(a, Math.min(b, v));
    }

    private record ScreenPoint(float x, float y) {
    }

    private record RenderEntry(PlayerEntity player, float screenX, float screenY, double distance) {
    }

    private record TagLayout(String header, List<ItemEntry> itemEntries, int maxEnchantLines, List<StatusEffectInstance> effects, int itemWidth, int effectsWidth, int itemY, int enchantTopY, int effectsY, int durabilityY, int headerX, int headerX1, int headerY1, int headerX2, int headerY2, float scale, float anchorX, float anchorY, ScreenRect bounds) {
    }

    private static final class PreparedEntry {
        private final RenderEntry entry;
        private final TagLayout layout;
        private float alphaMultiplier = 1.0f;

        private PreparedEntry(RenderEntry entry, TagLayout layout) {
            this.entry = entry;
            this.layout = layout;
        }

        public RenderEntry entry() {
            return this.entry;
        }

        public TagLayout layout() {
            return this.layout;
        }

        public float alphaMultiplier() {
            return this.alphaMultiplier;
        }

        public void setAlphaMultiplier(float alphaMultiplier) {
            this.alphaMultiplier = alphaMultiplier;
        }
    }

    private record ScreenRect(float x1, float y1, float x2, float y2) {
        private boolean intersects(ScreenRect other) {
            return this.x2 > other.x1 && this.x1 < other.x2 && this.y2 > other.y1 && this.y1 < other.y2;
        }
    }

    private record ItemEntry(ItemStack stack, List<String> enchantLines, boolean armorPiece, boolean handItem) {
    }

    private record EnchantLine(String name, int level) {
    }

    private static final class SmoothedPoint {
        private float x;
        private float y;

        private SmoothedPoint(float x, float y) {
            this.x = x;
            this.y = y;
        }
    }
}

