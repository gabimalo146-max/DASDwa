package me.Gui.gui.ui.widget;

import me.Gui.gui.ui.GuiFonts;
import me.Gui.gui.ui.render.Rounded;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;

public class UiButton {
    public int x;
    public int y;
    public int w;
    public int h;
    public Text label;
    public boolean enabled = true;
    private final Runnable onClick;

    public UiButton(int x, int y, int w, int h, Text label, Runnable onClick) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.label = label;
        this.onClick = onClick;
    }

    public boolean isHover(int mx, int my) {
        return mx >= this.x && my >= this.y && mx < this.x + this.w && my < this.y + this.h;
    }

    public void render(DrawContext ctx, int mx, int my, int bg, int fg) {
        int color = bg;
        if (!this.enabled) {
            color = bg & 0xFFFFFF | 0x33000000;
        } else if (this.isHover(mx, my)) {
            color = bg & 0xFFFFFF | 0xAA000000;
        }
        float r = Math.min((float)this.h * 0.45f, 8.0f);
        Rounded.rect(ctx, this.x, this.y, this.w, this.h, r, color);
        TextRenderer tr = GuiFonts.textRenderer();
        int tx = this.x + (this.w - tr.getWidth((StringVisitable)this.label)) / 2;
        int ty = this.y + (this.h - 8) / 2;
        ctx.drawText(tr, this.label, tx, ty, fg, false);
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (!this.enabled) {
            return false;
        }
        if (button != 0) {
            return false;
        }
        if (this.isHover((int)mx, (int)my)) {
            if (this.onClick != null) {
                this.onClick.run();
            }
            return true;
        }
        return false;
    }
}

