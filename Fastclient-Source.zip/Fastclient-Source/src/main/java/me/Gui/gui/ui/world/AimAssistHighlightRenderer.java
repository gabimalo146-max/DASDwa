package me.Gui.gui.ui.world;

import com.mojang.blaze3d.systems.RenderSystem;
import me.Gui.gui.modules.AimAssistUtil;
import me.Gui.gui.ui.Theme;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class AimAssistHighlightRenderer {
    private static final float FILL_ALPHA = 0.2f;
    private static final float OUTLINE_ALPHA = 0.85f;
    private static final float OUTLINE_WIDTH = 2.5f;
    private static final double BOX_INFLATE = 0.02;

    private AimAssistHighlightRenderer() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void render(WorldRenderContext context) {
        if (!AimAssistUtil.isTargetLockEnabled()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.world == null || client.player == null) {
            return;
        }
        Entity target = AimAssistUtil.getLockedEntity(client);
        if (target == null || target.isRemoved()) {
            return;
        }
        Camera camera = context.camera();
        if (camera == null) {
            return;
        }
        float tickDelta = context.tickCounter().getTickDelta(true);
        Box box = AimAssistHighlightRenderer.lerpedBox(target, tickDelta);
        if (box == null) {
            return;
        }
        box = box.expand(0.02);
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camPos = camera.getPos();
        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask((boolean)false);
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.POSITION_COLOR);
        float[] prevColor = RenderSystem.getShaderColor();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        float prevLine = RenderSystem.getShaderLineWidth();
        int rgb = Theme.accentColor(System.currentTimeMillis()) & 0xFFFFFF;
        Color fill = AimAssistHighlightRenderer.colorFromRgb(rgb, 0.2f);
        Color line = AimAssistHighlightRenderer.colorFromRgb(rgb, 0.85f);
        try {
            Tessellator tess = Tessellator.getInstance();
            Matrix4f mat = matrices.peek().getPositionMatrix();
            BufferBuilder fillBuf = tess.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
            AimAssistHighlightRenderer.addFilledBox(fillBuf, mat, box, fill.r, fill.g, fill.b, fill.a);
            BuiltBuffer fillBuilt = fillBuf.end();
            BufferRenderer.drawWithGlobalProgram((BuiltBuffer)fillBuilt);
            fillBuilt.close();
            RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.RENDERTYPE_LINES);
            RenderSystem.lineWidth((float)2.5f);
            BufferBuilder lineBuf = tess.begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
            AimAssistHighlightRenderer.addBox(lineBuf, mat, box, line.r, line.g, line.b, line.a);
            BuiltBuffer lineBuilt = lineBuf.end();
            BufferRenderer.drawWithGlobalProgram((BuiltBuffer)lineBuilt);
            lineBuilt.close();
        }
        finally {
            RenderSystem.lineWidth((float)prevLine);
            RenderSystem.setShaderColor((float)prevColor[0], (float)prevColor[1], (float)prevColor[2], (float)prevColor[3]);
            RenderSystem.disableBlend();
            RenderSystem.enableCull();
            RenderSystem.depthMask((boolean)true);
            RenderSystem.enableDepthTest();
            matrices.pop();
        }
    }

    private static Box lerpedBox(Entity entity, float tickDelta) {
        double oz;
        double oy;
        double ox;
        if (entity == null) {
            return null;
        }
        Vec3d pos = entity.getLerpedPos(tickDelta);
        Box bb = entity.getBoundingBox();
        Box box = bb.offset(ox = pos.x - entity.getX(), oy = pos.y - entity.getY(), oz = pos.z - entity.getZ());
        if (!AimAssistHighlightRenderer.isFinite(box)) {
            return null;
        }
        return box;
    }

    private static boolean isFinite(Box box) {
        if (box == null) {
            return false;
        }
        return Double.isFinite(box.minX) && Double.isFinite(box.minY) && Double.isFinite(box.minZ) && Double.isFinite(box.maxX) && Double.isFinite(box.maxY) && Double.isFinite(box.maxZ);
    }

    private static void addBox(BufferBuilder buf, Matrix4f mat, Box box, float r, float g, float b, float a) {
        double x1 = box.minX;
        double y1 = box.minY;
        double z1 = box.minZ;
        double x2 = box.maxX;
        double y2 = box.maxY;
        double z2 = box.maxZ;
        Vec3d a1 = new Vec3d(x1, y1, z1);
        Vec3d a2 = new Vec3d(x2, y1, z1);
        Vec3d a3 = new Vec3d(x2, y1, z2);
        Vec3d a4 = new Vec3d(x1, y1, z2);
        Vec3d b1 = new Vec3d(x1, y2, z1);
        Vec3d b2 = new Vec3d(x2, y2, z1);
        Vec3d b3 = new Vec3d(x2, y2, z2);
        Vec3d b4 = new Vec3d(x1, y2, z2);
        AimAssistHighlightRenderer.addLine(buf, mat, a1, a2, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, a2, a3, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, a3, a4, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, a4, a1, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, b1, b2, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, b2, b3, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, b3, b4, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, b4, b1, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, a1, b1, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, a2, b2, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, a3, b3, r, g, b, a);
        AimAssistHighlightRenderer.addLine(buf, mat, a4, b4, r, g, b, a);
    }

    private static void addFilledBox(BufferBuilder buf, Matrix4f mat, Box box, float r, float g, float b, float a) {
        float x1 = (float)box.minX;
        float y1 = (float)box.minY;
        float z1 = (float)box.minZ;
        float x2 = (float)box.maxX;
        float y2 = (float)box.maxY;
        float z2 = (float)box.maxZ;
        AimAssistHighlightRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        AimAssistHighlightRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
    }

    private static void v(BufferBuilder buf, Matrix4f mat, float x, float y, float z, float r, float g, float b, float a) {
        buf.vertex(mat, x, y, z).color(r, g, b, a);
    }

    private static void addLine(BufferBuilder buf, Matrix4f mat, Vec3d a, Vec3d b, float red, float green, float blue, float alpha) {
        float nz;
        float ny;
        float nx;
        Vec3d dir = b.subtract(a);
        double len = dir.length();
        if (len < 1.0E-6) {
            nx = 0.0f;
            ny = 1.0f;
            nz = 0.0f;
        } else {
            nx = (float)(dir.x / len);
            ny = (float)(dir.y / len);
            nz = (float)(dir.z / len);
        }
        buf.vertex(mat, (float)a.x, (float)a.y, (float)a.z).color(red, green, blue, alpha).normal(nx, ny, nz);
        buf.vertex(mat, (float)b.x, (float)b.y, (float)b.z).color(red, green, blue, alpha).normal(nx, ny, nz);
    }

    private static Color colorFromRgb(int rgb, float alpha) {
        int c = rgb & 0xFFFFFF;
        float r = (float)(c >>> 16 & 0xFF) / 255.0f;
        float g = (float)(c >>> 8 & 0xFF) / 255.0f;
        float b = (float)(c & 0xFF) / 255.0f;
        float a = Math.max(0.0f, Math.min(1.0f, alpha));
        return new Color(r, g, b, a);
    }

    private record Color(float r, float g, float b, float a) {
    }
}

