package me.Gui.gui.ui.world;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import me.Gui.gui.client.GuiClient;
import me.Gui.gui.config.GuiConfig;
import me.Gui.gui.modules.HackModule;
import me.Gui.gui.modules.ModuleId;
import me.Gui.gui.ui.Theme;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;

public final class PearlTrajectoryRenderer {
    private static final double GRAVITY = 0.03;
    private static final double DRAG = 0.99;
    private static final int MAX_STEPS = 200;

    private PearlTrajectoryRenderer() {
    }

    public static void render(WorldRenderContext context) {
        Camera camera;
        boolean showOwn;
        HackModule mod = GuiClient.MODULES.byId(ModuleId.PEARL_TRAJECTORY);
        if (mod == null || !mod.isEnabled()) {
            return;
        }
        GuiConfig cfg = GuiClient.CONFIG;
        boolean showTrajectory = cfg.pearlShowTrajectory == null || cfg.pearlShowTrajectory != false;
        boolean showLanding = cfg.pearlShowLanding == null || cfg.pearlShowLanding != false;
        boolean showNickname = cfg.pearlShowNickname == null || cfg.pearlShowNickname != false;
        boolean showCountdown = cfg.pearlShowCountdown == null || cfg.pearlShowCountdown != false;
        boolean bl = showOwn = cfg.pearlShowOwn == null || cfg.pearlShowOwn != false;
        if (!(showTrajectory || showLanding || showNickname || showCountdown)) {
            return;
        }
        ClientWorld world = context.world();
        if (world == null) {
            return;
        }
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        if ((camera = context.camera()) == null) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return;
        }
        int accent = Theme.accentColor(System.currentTimeMillis());
        int lineColor = Theme.withAlpha(accent, 255);
        float lineWidth = PearlTrajectoryRenderer.clamp(cfg.pearlLineWidth, 1.0f, 12.0f);
        float thickness = 0.04f + lineWidth * 0.04f;
        float rf = (float)(lineColor >>> 16 & 0xFF) / 255.0f;
        float gf = (float)(lineColor >>> 8 & 0xFF) / 255.0f;
        float bf = (float)(lineColor & 0xFF) / 255.0f;
        float af = (float)(lineColor >>> 24 & 0xFF) / 255.0f;
        ArrayList<TrajectoryRender> toRender = new ArrayList<TrajectoryRender>();
        ClientPlayerEntity self = client.player;
        for (Entity e : world.getEntities()) {
            Entity owner;
            EnderPearlEntity pearl;
            if (!(e instanceof EnderPearlEntity) || (pearl = (EnderPearlEntity)e).isRemoved() || !showOwn && self != null && (owner = pearl.getOwner()) != null && owner.getUuid().equals(self.getUuid())) continue;
            TrajectoryResult res = PearlTrajectoryRenderer.simulate(pearl, world);
            if (res.points.size() < 2) continue;
            toRender.add(new TrajectoryRender(res));
        }
        if (toRender.isEmpty()) {
            return;
        }
        Vec3d camPos = camera.getPos();
        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask((boolean)false);
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        float[] sc = RenderSystem.getShaderColor();
        RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        if (showTrajectory) {
            float prevLine = RenderSystem.getShaderLineWidth();
            float outerWidth = Math.max(1.0f, lineWidth * 2.4f);
            float innerWidth = Math.max(1.0f, lineWidth * 1.4f);
            RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.RENDERTYPE_LINES);
            PearlTrajectoryRenderer.drawLinePass(mat, toRender, outerWidth, rf, gf, bf, af * 0.35f);
            PearlTrajectoryRenderer.drawLinePass(mat, toRender, innerWidth, rf, gf, bf, af);
            RenderSystem.lineWidth((float)prevLine);
            RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.POSITION_COLOR);
        }
        if (showLanding) {
            Tessellator tess = Tessellator.getInstance();
            BufferBuilder buf = tess.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
            for (TrajectoryRender tr : toRender) {
                if (tr.result.hitPos != null) {
                    PearlTrajectoryRenderer.drawCross(buf, mat, tr.result.hitPos, thickness, rf, gf, bf, af);
                }
                if (tr.result.hitBlock == null) continue;
                PearlTrajectoryRenderer.drawLandingBlock(buf, mat, tr.result.hitBlock, rf, gf, bf);
            }
            BuiltBuffer built = buf.end();
            BufferRenderer.drawWithGlobalProgram((BuiltBuffer)built);
            built.close();
        }
        VertexConsumerProvider.Immediate consumers = client.getBufferBuilders().getEntityVertexConsumers();
        if (showNickname || showCountdown) {
            float labelLift = 0.85f + lineWidth * 0.06f;
            PearlTrajectoryRenderer.renderLabels(matrices, camera, consumers, toRender, accent, showNickname, showCountdown, labelLift);
        }
        consumers.draw();
        RenderSystem.setShaderColor((float)sc[0], (float)sc[1], (float)sc[2], (float)sc[3]);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.depthMask((boolean)true);
        RenderSystem.enableDepthTest();
        matrices.pop();
    }

    private static void renderLabels(MatrixStack matrices, Camera camera, VertexConsumerProvider.Immediate consumers, List<TrajectoryRender> list, int accent, boolean showNickname, boolean showCountdown, float labelLift) {
        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer tr = client.textRenderer;
        int color = Theme.withAlpha(accent, 255);
        for (TrajectoryRender r : list) {
            String label;
            Vec3d hit = r.result.hitPos;
            if (hit == null || (label = PearlTrajectoryRenderer.buildLabel(r.result, showNickname, showCountdown)).isBlank()) continue;
            Vec3d textPos = hit.add(0.0, (double)labelLift, 0.0);
            PearlTrajectoryRenderer.drawLabel(matrices, camera, tr, consumers, textPos, label, color);
        }
    }

    private static void drawLabel(MatrixStack matrices, Camera camera, TextRenderer tr, VertexConsumerProvider.Immediate consumers, Vec3d pos, String text, int color) {
        matrices.push();
        matrices.translate(pos.x, pos.y, pos.z);
        matrices.multiply(camera.getRotation());
        Vec3d camPos = camera.getPos();
        double dist = camPos.distanceTo(pos);
        float scale = PearlTrajectoryRenderer.clamp(0.045f + (float)dist * 0.0012f, 0.045f, 0.12f);
        matrices.scale(scale, -scale, scale);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        float x = (float)(-tr.getWidth(text)) / 2.0f;
        float pad = 3.0f;
        float w = tr.getWidth(text);
        Objects.requireNonNull(tr);
        float h = 9.0f;
        PearlTrajectoryRenderer.drawLabelBackground(mat, x - pad, -pad, w + pad * 2.0f, h + pad * 2.0f, -805306368);
        int outline = -16777216;
        tr.draw(text, x - 1.0f, -1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x + 1.0f, -1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x - 1.0f, 1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x + 1.0f, 1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x - 1.0f, 0.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x + 1.0f, 0.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x, -1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x, 1.0f, outline, false, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        tr.draw(text, x, 0.0f, color, true, mat, (VertexConsumerProvider)consumers, TextRenderer.TextLayerType.SEE_THROUGH, 0, 0xF000F0);
        matrices.pop();
    }

    private static void drawLinePass(Matrix4f mat, List<TrajectoryRender> list, float width, float r, float g, float b, float a) {
        if (list.isEmpty()) {
            return;
        }
        RenderSystem.lineWidth((float)width);
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
        for (TrajectoryRender tr : list) {
            List<Vec3d> points = tr.result.points;
            if (points.size() < 2) continue;
            Vec3d prev = points.get(0);
            for (int i = 1; i < points.size(); ++i) {
                Vec3d p = points.get(i);
                PearlTrajectoryRenderer.addLine(buf, mat, prev, p, r, g, b, a);
                prev = p;
            }
        }
        BuiltBuffer built = buf.end();
        BufferRenderer.drawWithGlobalProgram((BuiltBuffer)built);
        built.close();
    }

    private static void addLine(BufferBuilder buf, Matrix4f mat, Vec3d a, Vec3d b, float red, float green, float blue, float alpha) {
        float nz;
        float ny;
        float nx;
        Vec3d dir = b.subtract(a);
        double len = dir.length();
        if (len < 1.0E-6) {
            nx = 0.0f;
            ny = 1.0f;
            nz = 0.0f;
        } else {
            nx = (float)(dir.x / len);
            ny = (float)(dir.y / len);
            nz = (float)(dir.z / len);
        }
        buf.vertex(mat, (float)a.x, (float)a.y, (float)a.z).color(red, green, blue, alpha).normal(nx, ny, nz);
        buf.vertex(mat, (float)b.x, (float)b.y, (float)b.z).color(red, green, blue, alpha).normal(nx, ny, nz);
    }

    private static void drawCross(BufferBuilder buf, Matrix4f mat, Vec3d pos, float thickness, float r, float g, float b, float a) {
        double size = 0.45 + (double)thickness * 2.4;
        Vec3d p = pos.add(0.0, 0.02, 0.0);
        Vec3d p1 = p.add(-size, 0.0, 0.0);
        Vec3d p2 = p.add(size, 0.0, 0.0);
        Vec3d p3 = p.add(0.0, 0.0, -size);
        Vec3d p4 = p.add(0.0, 0.0, size);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, p1, p2, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, p3, p4, thickness, r, g, b, a);
    }

    private static void drawLandingBlock(BufferBuilder buf, Matrix4f mat, BlockPos pos, float r, float g, float b) {
        double x = pos.getX();
        double y = pos.getY();
        double z = pos.getZ();
        double eps = 0.002;
        double minX = x - eps;
        double minY = y - eps;
        double minZ = z - eps;
        double maxX = x + 1.0 + eps;
        double maxY = y + 1.0 + eps;
        double maxZ = z + 1.0 + eps;
        PearlTrajectoryRenderer.addBox(buf, mat, minX, minY, minZ, maxX, maxY, maxZ, r, g, b, 0.18f);
        float edge = 0.03f;
        PearlTrajectoryRenderer.drawOutlineBox(buf, mat, minX, minY, minZ, maxX, maxY, maxZ, edge, r, g, b, 0.95f);
    }

    private static void drawOutlineBox(BufferBuilder buf, Matrix4f mat, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float thickness, float r, float g, float b, float a) {
        double x1 = minX;
        double y1 = minY;
        double z1 = minZ;
        double x2 = maxX;
        double y2 = maxY;
        double z2 = maxZ;
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x1, y1, z1, x2, y1, z1, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x1, y1, z2, x2, y1, z2, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x1, y2, z1, x2, y2, z1, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x1, y2, z2, x2, y2, z2, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x1, y1, z1, x1, y2, z1, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x2, y1, z1, x2, y2, z1, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x1, y1, z2, x1, y2, z2, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x2, y1, z2, x2, y2, z2, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x1, y1, z1, x1, y1, z2, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x2, y1, z1, x2, y1, z2, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x1, y2, z1, x1, y2, z2, thickness, r, g, b, a);
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, x2, y2, z1, x2, y2, z2, thickness, r, g, b, a);
    }

    private static void drawThickSegment(BufferBuilder buf, Matrix4f mat, Vec3d a, Vec3d b, float thickness, float red, float green, float blue, float alpha) {
        PearlTrajectoryRenderer.drawThickSegment(buf, mat, a.x, a.y, a.z, b.x, b.y, b.z, thickness, red, green, blue, alpha);
    }

    private static void drawThickSegment(BufferBuilder buf, Matrix4f mat, double ax, double ay, double az, double bx, double by, double bz, float thickness, float red, float green, float blue, float alpha) {
        double minX = Math.min(ax, bx) - (double)thickness;
        double minY = Math.min(ay, by) - (double)thickness;
        double minZ = Math.min(az, bz) - (double)thickness;
        double maxX = Math.max(ax, bx) + (double)thickness;
        double maxY = Math.max(ay, by) + (double)thickness;
        double maxZ = Math.max(az, bz) + (double)thickness;
        PearlTrajectoryRenderer.addBox(buf, mat, minX, minY, minZ, maxX, maxY, maxZ, red, green, blue, alpha);
    }

    private static void addBox(BufferBuilder buf, Matrix4f mat, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, float r, float g, float b, float a) {
        float x1 = (float)minX;
        float y1 = (float)minY;
        float z1 = (float)minZ;
        float x2 = (float)maxX;
        float y2 = (float)maxY;
        float z2 = (float)maxZ;
        PearlTrajectoryRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y1, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y1, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y1, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y1, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y2, z1, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, z2, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x1, y2, z2, r, g, b, a);
    }

    private static void v(BufferBuilder buf, Matrix4f mat, float x, float y, float z, float r, float g, float b, float a) {
        buf.vertex(mat, x, y, z).color(r, g, b, a);
    }

    private static void drawLabelBackground(Matrix4f mat, float x, float y, float w, float h, int argb) {
        float r = (float)(argb >>> 16 & 0xFF) / 255.0f;
        float g = (float)(argb >>> 8 & 0xFF) / 255.0f;
        float b = (float)(argb & 0xFF) / 255.0f;
        float a = (float)(argb >>> 24 & 0xFF) / 255.0f;
        RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        float x2 = x + w;
        float y2 = y + h;
        PearlTrajectoryRenderer.v(buf, mat, x, y, 0.0f, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y, 0.0f, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, 0.0f, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x, y, 0.0f, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x2, y2, 0.0f, r, g, b, a);
        PearlTrajectoryRenderer.v(buf, mat, x, y2, 0.0f, r, g, b, a);
        BuiltBuffer built = buf.end();
        BufferRenderer.drawWithGlobalProgram((BuiltBuffer)built);
        built.close();
    }

    private static float clamp(float v, float a, float b) {
        return Math.max(a, Math.min(b, v));
    }

    private static TrajectoryResult simulate(EnderPearlEntity pearl, ClientWorld world) {
        Vec3d pos = pearl.getPos();
        Vec3d vel = pearl.getVelocity();
        ArrayList<Vec3d> points = new ArrayList<Vec3d>();
        points.add(pos);
        Vec3d hitPos = null;
        BlockPos hitBlock = null;
        double timeSec = 0.0;
        for (int i = 0; i < 200; ++i) {
            Vec3d next = pos.add(vel);
            BlockHitResult hit = world.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, (Entity)pearl));
            if (hit.getType() != HitResult.Type.MISS) {
                hitPos = hit.getPos();
                if (hit instanceof BlockHitResult) {
                    BlockHitResult bhr = hit;
                    hitBlock = bhr.getBlockPos();
                }
                points.add(hitPos);
                double segLen = pos.distanceTo(next);
                double frac = segLen > 1.0E-6 ? pos.distanceTo(hitPos) / segLen : 0.0;
                timeSec = ((double)i + frac) / 20.0;
                break;
            }
            pos = next;
            points.add(pos);
            vel = new Vec3d(vel.x * 0.99, (vel.y - 0.03) * 0.99, vel.z * 0.99);
            if (pos.y < (double)(world.getBottomY() - 2)) break;
        }
        if (hitPos == null) {
            timeSec = (double)(points.size() - 1) / 20.0;
            hitPos = (Vec3d)points.get(points.size() - 1);
        }
        if (hitBlock == null && hitPos != null) {
            hitBlock = BlockPos.ofFloored(hitPos);
        }
        String owner = PearlTrajectoryRenderer.resolveOwnerName(pearl);
        return new TrajectoryResult(points, hitPos, hitBlock, timeSec, owner);
    }

    private static String resolveOwnerName(EnderPearlEntity pearl) {
        String n;
        Entity owner = pearl.getOwner();
        if (owner instanceof PlayerEntity) {
            PlayerEntity player = (PlayerEntity)owner;
            String base = player.getName().getString();
            String display = GuiClient.FRIENDS.getDisplayName(base);
            if (display != null && !display.isBlank()) {
                return display;
            }
            return base;
        }
        if (owner != null && (n = owner.getName().getString()) != null && !n.isBlank()) {
            return n;
        }
        return "Unknown";
    }

    private static String formatTime(double timeSec) {
        return String.format(Locale.US, "%.1fs", Math.max(0.0, timeSec));
    }

    private static String buildLabel(TrajectoryResult result, boolean showNickname, boolean showCountdown) {
        String time;
        String name = showNickname ? result.ownerName : "";
        String string = time = showCountdown ? PearlTrajectoryRenderer.formatTime(result.timeSec) : "";
        if (name.isBlank()) {
            return time;
        }
        if (time.isBlank()) {
            return name;
        }
        return name + " " + time;
    }

    private record TrajectoryResult(List<Vec3d> points, Vec3d hitPos, BlockPos hitBlock, double timeSec, String ownerName) {
    }

    private record TrajectoryRender(TrajectoryResult result) {
    }
}

