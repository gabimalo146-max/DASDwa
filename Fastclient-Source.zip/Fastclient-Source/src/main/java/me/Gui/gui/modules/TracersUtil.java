package me.Gui.gui.modules;

import java.util.ArrayList;
import java.util.List;
import me.Gui.gui.client.GuiClient;
import me.Gui.gui.config.GuiConfig;
import me.Gui.gui.modules.HackModule;
import me.Gui.gui.modules.ModuleId;
import me.Gui.gui.ui.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class TracersUtil {
    private static final float WHITE_HUE_START = 0.97f;
    private static Boolean prevBobbing = null;
    private static boolean bobbingForced = false;

    private TracersUtil() {
    }

    public static List<Target> collect(MinecraftClient client) {
        float tickDelta = 0.0f;
        if (client != null) {
            tickDelta = client.getRenderTickCounter().getTickDelta(true);
        }
        return TracersUtil.collect(client, tickDelta);
    }

    public static List<Target> collect(MinecraftClient client, float tickDelta) {
        ArrayList<Target> out = new ArrayList<Target>();
        if (client == null || client.world == null) {
            return out;
        }
        if (!TracersUtil.isEnabled()) {
            return out;
        }
        ClientWorld world = client.world;
        GuiConfig cfg = GuiClient.CONFIG;
        boolean showPlayers = cfg.tracerPlayers == null || cfg.tracerPlayers != false;
        boolean showMobs = cfg.tracerMobs == null || cfg.tracerMobs != false;
        boolean showFriends = cfg.tracerFriends == null || cfg.tracerFriends != false;
        int playerColor = TracersUtil.hueToRgbAllowWhite(cfg.tracerPlayerHue);
        int mobColor = TracersUtil.hueToRgbAllowWhite(cfg.tracerMobHue);
        int friendColor = TracersUtil.hueToRgbAllowWhite(cfg.tracerFriendHue);
        double maxDist = cfg.tracerDistance;
        double maxSq = maxDist * maxDist;
        for (Entity e : world.getEntities()) {
            if (!(e instanceof LivingEntity)) continue;
            LivingEntity living = (LivingEntity)e;
            if (client.player != null && e.getId() == client.player.getId()) continue;
            Vec3d base = living.getLerpedPos(tickDelta);
            double eye = living.getEyeHeight(living.getPose());
            Vec3d pos = base.add(0.0, eye, 0.0);
            if (client.player != null) {
                Vec3d selfPos = client.player.getLerpedPos(tickDelta);
                double dx = pos.x - selfPos.x;
                double dz = pos.z - selfPos.z;
                if (dx * dx + dz * dz > maxSq) continue;
            }
            if (e instanceof PlayerEntity) {
                PlayerEntity player = (PlayerEntity)e;
                String name = player.getName().getString();
                boolean isFriend = GuiClient.FRIENDS.isFriend(name);
                if (isFriend) {
                    if (!showFriends) continue;
                    out.add(new Target(pos, friendColor));
                    continue;
                }
                if (!showPlayers) continue;
                out.add(new Target(pos, playerColor));
                continue;
            }
            if (!showMobs) continue;
            out.add(new Target(pos, mobColor));
        }
        return out;
    }

    public static void syncViewBobbing(MinecraftClient client) {
        if (client == null) {
            return;
        }
        SimpleOption opt = client.options.getBobView();
        if (TracersUtil.isEnabled()) {
            if (!bobbingForced) {
                prevBobbing = (Boolean)opt.getValue();
                bobbingForced = true;
            }
            if (Boolean.TRUE.equals(opt.getValue())) {
                opt.setValue((Object)false);
            }
        } else if (bobbingForced) {
            if (prevBobbing != null) {
                opt.setValue((Object)prevBobbing);
            }
            prevBobbing = null;
            bobbingForced = false;
        }
    }

    private static boolean isEnabled() {
        HackModule mod = GuiClient.MODULES.byId(ModuleId.TRACERS);
        return mod != null && mod.isEnabled();
    }

    private static int hueToRgbAllowWhite(float hue) {
        if (Float.isNaN(hue) || Float.isInfinite(hue)) {
            hue = 0.0f;
        }
        if (hue >= 0.97f) {
            return -1;
        }
        return Theme.hsvToRgb(hue, 1.0f, 1.0f);
    }

    public record Target(Vec3d pos, int color) {
    }
}

