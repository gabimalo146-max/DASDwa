package me.Gui.gui.ui.widget;

import java.util.Objects;
import me.Gui.gui.ui.GuiFonts;
import me.Gui.gui.ui.render.Rounded;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class UiColorSlider {
    private static final float[] COLOR_STOPS = new float[]{0.0f, 0.14f, 0.28f, 0.42f, 0.56f, 0.7f, 0.84f, 1.0f};
    private static final int[] STOP_COLORS = new int[]{0, 0xFF0000, 0xFFFF00, 65280, 65535, 255, 0xFF00FF, 0xFFFFFF};
    public int x;
    public int y;
    public int w;
    public int h;
    public String label;
    public float value;
    public boolean dragging = false;
    private final ColorChanged onChange;

    public UiColorSlider(int x, int y, int w, int h, String label, int initialRgb, ColorChanged onChange) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.label = label == null ? "" : label;
        this.value = (float)UiColorSlider.findNearestColorPosition(initialRgb & 0xFFFFFF);
        this.onChange = onChange;
    }

    public void setBounds(int x, int y, int w, int h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }

    public void syncRgb(int rgb) {
        if (this.dragging) {
            return;
        }
        this.value = (float)UiColorSlider.findNearestColorPosition(rgb & 0xFFFFFF);
    }

    public void render(DrawContext ctx, int mx, int my, int bg, int textCol, int accent) {
        float r = Math.min((float)this.h * 0.45f, 8.0f);
        Rounded.rect(ctx, this.x, this.y, this.w, this.h, r, bg);
        int pad = 8;
        int barX = this.x + pad;
        int barW = Math.max(1, this.w - pad * 2);
        int barY1 = this.y + this.h - 8;
        int barY2 = this.y + this.h - 4;
        int barH = Math.max(1, barY2 - barY1);
        for (int i = 0; i < barW; ++i) {
            float t = barW <= 1 ? 0.0f : (float)i / (float)(barW - 1);
            int color = 0xFF000000 | UiColorSlider.colorFromPosition(t);
            ctx.fill(barX + i, barY1, barX + i + 1, barY1 + barH, color);
        }
        int knobX = barX + Math.round(this.value * (float)(barW - 1));
        int knobTop = barY1 - 2;
        int knobBot = barY1 + barH + 2;
        ctx.fill(knobX - 1, knobTop, knobX + 2, knobBot, -1);
        TextRenderer tr = GuiFonts.textRenderer();
        String msg = this.label.isBlank() ? this.colorHex() : this.label + ": " + this.colorHex();
        int lx = this.x + (int)Math.ceil(r) + 2;
        Objects.requireNonNull(tr);
        int ly = this.y + (this.h - 9) / 2;
        ctx.drawText(tr, (Text)Text.literal((String)msg), lx, ly, textCol, false);
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) {
            return false;
        }
        if (this.isHover((int)mx, (int)my)) {
            this.dragging = true;
            this.setFromMouse(mx);
            return true;
        }
        return false;
    }

    public void mouseReleased(double mx, double my, int button) {
        if (button == 0) {
            this.dragging = false;
        }
    }

    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (button != 0 || !this.dragging) {
            return false;
        }
        this.setFromMouse(mx);
        return true;
    }

    private boolean isHover(int mx, int my) {
        return mx >= this.x && my >= this.y && mx < this.x + this.w && my < this.y + this.h;
    }

    private void setFromMouse(double mx) {
        double t = (mx - (double)(this.x + 8)) / (double)(this.w - 16);
        this.value = UiColorSlider.clamp01((float)t);
        if (this.onChange != null) {
            this.onChange.onChanged(UiColorSlider.colorFromPosition(this.value));
        }
    }

    private String colorHex() {
        return String.format("#%06X", UiColorSlider.colorFromPosition(this.value));
    }

    private static float clamp01(float v) {
        return Math.max(0.0f, Math.min(1.0f, v));
    }

    private static int colorFromPosition(float t) {
        float clamped = Math.max(0.0f, Math.min(1.0f, t));
        for (int i = 0; i < COLOR_STOPS.length - 1; ++i) {
            float left = COLOR_STOPS[i];
            float right = COLOR_STOPS[i + 1];
            if (!(clamped <= right) && i != COLOR_STOPS.length - 2) continue;
            float local = right <= left ? 0.0f : (clamped - left) / (right - left);
            return UiColorSlider.interpolateRgb(STOP_COLORS[i], STOP_COLORS[i + 1], local);
        }
        return STOP_COLORS[STOP_COLORS.length - 1];
    }

    private static int interpolateRgb(int from, int to, float t) {
        float clamped = Math.max(0.0f, Math.min(1.0f, t));
        int fr = from >> 16 & 0xFF;
        int fg = from >> 8 & 0xFF;
        int fb = from & 0xFF;
        int tr = to >> 16 & 0xFF;
        int tg = to >> 8 & 0xFF;
        int tb = to & 0xFF;
        int r = Math.round((float)fr + (float)(tr - fr) * clamped);
        int g = Math.round((float)fg + (float)(tg - fg) * clamped);
        int b = Math.round((float)fb + (float)(tb - fb) * clamped);
        return r << 16 | g << 8 | b;
    }

    private static double findNearestColorPosition(int targetRgb) {
        double bestDistance = Double.MAX_VALUE;
        double bestPosition = 0.0;
        for (int step = 0; step <= 1000; ++step) {
            float t = (float)step / 1000.0f;
            int color = UiColorSlider.colorFromPosition(t);
            double distance = UiColorSlider.colorDistanceSquared(targetRgb, color);
            if (!(distance < bestDistance)) continue;
            bestDistance = distance;
            bestPosition = t;
        }
        return bestPosition;
    }

    private static double colorDistanceSquared(int a, int b) {
        int ar = a >> 16 & 0xFF;
        int ag = a >> 8 & 0xFF;
        int ab = a & 0xFF;
        int br = b >> 16 & 0xFF;
        int bg = b >> 8 & 0xFF;
        int bb = b & 0xFF;
        int dr = ar - br;
        int dg = ag - bg;
        int db = ab - bb;
        return dr * dr + dg * dg + db * db;
    }

    public static interface ColorChanged {
        public void onChanged(int var1);
    }
}

