package me.Gui.gui.ui.world;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.List;
import me.Gui.gui.modules.TracersUtil;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class TracersWorldRenderer {
    private TracersWorldRenderer() {
    }

    public static void render(WorldRenderContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.world == null || client.player == null) {
            return;
        }
        if (client.options.getPerspective().isFirstPerson()) {
            return;
        }
        float tickDelta = context.tickCounter().getTickDelta(true);
        List<TracersUtil.Target> targets = TracersUtil.collect(client, tickDelta);
        if (targets.isEmpty()) {
            return;
        }
        Camera camera = context.camera();
        if (camera == null) {
            return;
        }
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) {
            matrices = new MatrixStack();
        }
        Vec3d camPos = camera.getPos();
        Vec3d start = client.player.getLerpedPos(tickDelta).add(0.0, (double)client.player.getEyeHeight(client.player.getPose()), 0.0);
        matrices.push();
        matrices.translate(-camPos.x, -camPos.y, -camPos.z);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask((boolean)false);
        RenderSystem.disableCull();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        float[] prevColor = RenderSystem.getShaderColor();
        RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
        RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.RENDERTYPE_LINES);
        float prevLine = RenderSystem.getShaderLineWidth();
        RenderSystem.lineWidth((float)2.0f);
        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
        Matrix4f mat = matrices.peek().getPositionMatrix();
        for (TracersUtil.Target t : targets) {
            int color = t.color();
            float r = (float)(color >>> 16 & 0xFF) / 255.0f;
            float g = (float)(color >>> 8 & 0xFF) / 255.0f;
            float b = (float)(color & 0xFF) / 255.0f;
            float a = (float)(color >>> 24 & 0xFF) / 255.0f;
            TracersWorldRenderer.addLine(buf, mat, start, t.pos(), r, g, b, a);
        }
        BuiltBuffer built = buf.end();
        BufferRenderer.drawWithGlobalProgram((BuiltBuffer)built);
        built.close();
        RenderSystem.lineWidth((float)prevLine);
        RenderSystem.setShaderColor((float)prevColor[0], (float)prevColor[1], (float)prevColor[2], (float)prevColor[3]);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
        RenderSystem.depthMask((boolean)true);
        RenderSystem.enableDepthTest();
        matrices.pop();
    }

    private static void addLine(BufferBuilder buf, Matrix4f mat, Vec3d a, Vec3d b, float red, float green, float blue, float alpha) {
        float nz;
        float ny;
        float nx;
        Vec3d dir = b.subtract(a);
        double len = dir.length();
        if (len < 1.0E-6) {
            nx = 0.0f;
            ny = 1.0f;
            nz = 0.0f;
        } else {
            nx = (float)(dir.x / len);
            ny = (float)(dir.y / len);
            nz = (float)(dir.z / len);
        }
        buf.vertex(mat, (float)a.x, (float)a.y, (float)a.z).color(red, green, blue, alpha).normal(nx, ny, nz);
        buf.vertex(mat, (float)b.x, (float)b.y, (float)b.z).color(red, green, blue, alpha).normal(nx, ny, nz);
    }
}

