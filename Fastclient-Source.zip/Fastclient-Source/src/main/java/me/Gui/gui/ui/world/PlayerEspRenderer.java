package me.Gui.gui.ui.world;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import me.Gui.gui.client.GuiClient;
import me.Gui.gui.config.GuiConfig;
import me.Gui.gui.modules.HackModule;
import me.Gui.gui.modules.ModuleId;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class PlayerEspRenderer {
    private PlayerEspRenderer() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void render(WorldRenderContext context) {
        block15: {
            boolean showBox;
            HackModule mod = GuiClient.MODULES.byId(ModuleId.ESP);
            if (mod == null || !mod.isEnabled()) {
                return;
            }
            GuiConfig cfg = GuiClient.CONFIG;
            boolean bl = showBox = cfg.espBox == null || cfg.espBox != false;
            if (!showBox) {
                return;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            if (client == null || client.world == null || client.player == null) {
                return;
            }
            Camera camera = context.camera();
            if (camera == null) {
                return;
            }
            float tickDelta = context.tickCounter().getTickDelta(true);
            ArrayList<PlayerEntity> players = new ArrayList<PlayerEntity>();
            for (PlayerEntity player : client.world.getPlayers()) {
                if (player == null || player == client.player || player.isSpectator()) continue;
                players.add(player);
            }
            if (players.isEmpty()) {
                return;
            }
            MatrixStack matrices = context.matrixStack();
            if (matrices == null) {
                matrices = new MatrixStack();
            }
            Vec3d camPos = camera.getPos();
            matrices.push();
            matrices.translate(-camPos.x, -camPos.y, -camPos.z);
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask((boolean)false);
            RenderSystem.disableCull();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.RENDERTYPE_LINES);
            float[] prevColor = RenderSystem.getShaderColor();
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            float prevLine = RenderSystem.getShaderLineWidth();
            try {
                Tessellator tess = Tessellator.getInstance();
                Matrix4f mat = matrices.peek().getPositionMatrix();
                float lineWidth = cfg.espLineWidth;
                if (Float.isNaN(lineWidth) || Float.isInfinite(lineWidth)) {
                    lineWidth = 4.0f;
                }
                lineWidth = PlayerEspRenderer.clamp(lineWidth, 1.0f, 6.0f);
                RenderSystem.lineWidth((float)lineWidth);
                BufferBuilder boxBuf = tess.begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
                boolean wrote = false;
                for (PlayerEntity player : players) {
                    Color c = PlayerEspRenderer.colorFor(player);
                    Box box = PlayerEspRenderer.lerpedBox(player, tickDelta);
                    if (box == null) continue;
                    PlayerEspRenderer.addBox(boxBuf, mat, box, c.r, c.g, c.b, c.a);
                    wrote = true;
                }
                if (!wrote) break block15;
                try {
                    BuiltBuffer built = boxBuf.endNullable();
                    if (built != null) {
                        BufferRenderer.drawWithGlobalProgram((BuiltBuffer)built);
                        built.close();
                    }
                }
                catch (IllegalStateException illegalStateException) {
                    // empty catch block
                }
            }
            finally {
                RenderSystem.lineWidth((float)prevLine);
                RenderSystem.setShaderColor((float)prevColor[0], (float)prevColor[1], (float)prevColor[2], (float)prevColor[3]);
                RenderSystem.disableBlend();
                RenderSystem.enableCull();
                RenderSystem.depthMask((boolean)true);
                RenderSystem.enableDepthTest();
                matrices.pop();
            }
        }
    }

    private static void addBox(BufferBuilder buf, Matrix4f mat, Box box, float r, float g, float b, float a) {
        double x1 = box.minX;
        double y1 = box.minY;
        double z1 = box.minZ;
        double x2 = box.maxX;
        double y2 = box.maxY;
        double z2 = box.maxZ;
        Vec3d a1 = new Vec3d(x1, y1, z1);
        Vec3d a2 = new Vec3d(x2, y1, z1);
        Vec3d a3 = new Vec3d(x2, y1, z2);
        Vec3d a4 = new Vec3d(x1, y1, z2);
        Vec3d b1 = new Vec3d(x1, y2, z1);
        Vec3d b2 = new Vec3d(x2, y2, z1);
        Vec3d b3 = new Vec3d(x2, y2, z2);
        Vec3d b4 = new Vec3d(x1, y2, z2);
        PlayerEspRenderer.addLine(buf, mat, a1, a2, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, a2, a3, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, a3, a4, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, a4, a1, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, b1, b2, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, b2, b3, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, b3, b4, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, b4, b1, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, a1, b1, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, a2, b2, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, a3, b3, r, g, b, a);
        PlayerEspRenderer.addLine(buf, mat, a4, b4, r, g, b, a);
    }

    private static Box lerpedBox(PlayerEntity player, float tickDelta) {
        double oz;
        double oy;
        double ox;
        if (player == null) {
            return null;
        }
        Vec3d pos = player.getLerpedPos(tickDelta);
        Box bb = player.getBoundingBox();
        Box box = bb.offset(ox = pos.x - player.getX(), oy = pos.y - player.getY(), oz = pos.z - player.getZ());
        if (!PlayerEspRenderer.isFinite(box)) {
            return null;
        }
        return box;
    }

    private static boolean isFinite(Box box) {
        if (box == null) {
            return false;
        }
        return Double.isFinite(box.minX) && Double.isFinite(box.minY) && Double.isFinite(box.minZ) && Double.isFinite(box.maxX) && Double.isFinite(box.maxY) && Double.isFinite(box.maxZ);
    }

    private static Color colorFor(PlayerEntity player) {
        if (player == null) {
            return new Color(1.0f, 1.0f, 1.0f, 0.85f);
        }
        GuiConfig cfg = GuiClient.CONFIG;
        String name = player.getName().getString().toLowerCase();
        boolean friend = GuiClient.FRIENDS.isFriend(name);
        int rgb = friend ? cfg.espFriendColor : cfg.espPlayerColor;
        return PlayerEspRenderer.colorFromRgb(rgb, 0.85f);
    }

    private static void addLine(BufferBuilder buf, Matrix4f mat, Vec3d a, Vec3d b, float red, float green, float blue, float alpha) {
        float nz;
        float ny;
        float nx;
        Vec3d dir = b.subtract(a);
        double len = dir.length();
        if (len < 1.0E-6) {
            nx = 0.0f;
            ny = 1.0f;
            nz = 0.0f;
        } else {
            nx = (float)(dir.x / len);
            ny = (float)(dir.y / len);
            nz = (float)(dir.z / len);
        }
        buf.vertex(mat, (float)a.x, (float)a.y, (float)a.z).color(red, green, blue, alpha).normal(nx, ny, nz);
        buf.vertex(mat, (float)b.x, (float)b.y, (float)b.z).color(red, green, blue, alpha).normal(nx, ny, nz);
    }

    private static Color colorFromRgb(int rgb, float alpha) {
        int c = rgb & 0xFFFFFF;
        float r = (float)(c >>> 16 & 0xFF) / 255.0f;
        float g = (float)(c >>> 8 & 0xFF) / 255.0f;
        float b = (float)(c & 0xFF) / 255.0f;
        float a = Math.max(0.0f, Math.min(1.0f, alpha));
        return new Color(r, g, b, a);
    }

    private static float clamp(float v, float a, float b) {
        return Math.max(a, Math.min(b, v));
    }

    private record Color(float r, float g, float b, float a) {
    }
}

