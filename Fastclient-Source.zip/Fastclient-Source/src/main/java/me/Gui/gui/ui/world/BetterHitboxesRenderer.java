package me.Gui.gui.ui.world;

import com.mojang.blaze3d.systems.RenderSystem;
import me.Gui.gui.modules.BetterHitboxesUtil;
import me.Gui.gui.ui.Theme;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public final class BetterHitboxesRenderer {
    private BetterHitboxesRenderer() {
    }

    /*
     * WARNING - Removed try catching itself - possible behaviour change.
     */
    public static void render(WorldRenderContext context) {
        block12: {
            if (!BetterHitboxesUtil.shouldRenderDebug()) {
                return;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            if (client == null || client.world == null || client.player == null) {
                return;
            }
            Camera camera = context.camera();
            if (camera == null) {
                return;
            }
            float scaleX = BetterHitboxesUtil.readScaleX();
            float scaleY = BetterHitboxesUtil.readScaleY();
            if (scaleX <= 0.0f && scaleY <= 0.0f) {
                return;
            }
            float tickDelta = context.tickCounter().getTickDelta(true);
            MatrixStack matrices = context.matrixStack();
            if (matrices == null) {
                matrices = new MatrixStack();
            }
            Vec3d camPos = camera.getPos();
            matrices.push();
            matrices.translate(-camPos.x, -camPos.y, -camPos.z);
            RenderSystem.disableDepthTest();
            RenderSystem.depthMask((boolean)false);
            RenderSystem.disableCull();
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            RenderSystem.setShader((ShaderProgramKey)ShaderProgramKeys.RENDERTYPE_LINES);
            float[] prevColor = RenderSystem.getShaderColor();
            RenderSystem.setShaderColor((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            float prevLine = RenderSystem.getShaderLineWidth();
            try {
                Tessellator tess = Tessellator.getInstance();
                Matrix4f mat = matrices.peek().getPositionMatrix();
                RenderSystem.lineWidth((float)2.0f);
                BufferBuilder boxBuf = tess.begin(VertexFormat.DrawMode.LINES, VertexFormats.LINES);
                boolean wrote = false;
                int color = Theme.withAlpha(Theme.accentColor(System.currentTimeMillis()), 200);
                float r = (float)(color >>> 16 & 0xFF) / 255.0f;
                float g = (float)(color >>> 8 & 0xFF) / 255.0f;
                float b = (float)(color & 0xFF) / 255.0f;
                float a = (float)(color >>> 24 & 0xFF) / 255.0f;
                for (Entity entity : client.world.getEntities()) {
                    LivingEntity le;
                    Box box;
                    if (!BetterHitboxesUtil.isTargetCandidate(client, entity) || (box = BetterHitboxesRenderer.expandedLerpedBox(le = (LivingEntity)entity, tickDelta, scaleX, scaleY)) == null) continue;
                    BetterHitboxesRenderer.addBox(boxBuf, mat, box, r, g, b, a);
                    wrote = true;
                }
                if (!wrote) break block12;
                try {
                    BuiltBuffer built = boxBuf.endNullable();
                    if (built != null) {
                        BufferRenderer.drawWithGlobalProgram((BuiltBuffer)built);
                        built.close();
                    }
                }
                catch (IllegalStateException illegalStateException) {
                    // empty catch block
                }
            }
            finally {
                RenderSystem.lineWidth((float)prevLine);
                RenderSystem.setShaderColor((float)prevColor[0], (float)prevColor[1], (float)prevColor[2], (float)prevColor[3]);
                RenderSystem.disableBlend();
                RenderSystem.enableCull();
                RenderSystem.depthMask((boolean)true);
                RenderSystem.enableDepthTest();
                matrices.pop();
            }
        }
    }

    private static Box expandedLerpedBox(LivingEntity entity, float tickDelta, float scaleX, float scaleY) {
        double oz;
        double oy;
        double ox;
        if (entity == null) {
            return null;
        }
        Vec3d pos = entity.getLerpedPos(tickDelta);
        Box bb = entity.getBoundingBox();
        if (bb == null) {
            return null;
        }
        double margin = entity.getTargetingMargin();
        Box base = bb.expand(margin);
        Box expanded = BetterHitboxesRenderer.scaleBox(base, scaleX, scaleY);
        Box box = expanded.offset(ox = pos.x - entity.getX(), oy = pos.y - entity.getY(), oz = pos.z - entity.getZ());
        if (!BetterHitboxesRenderer.isFinite(box)) {
            return null;
        }
        return box;
    }

    private static boolean isFinite(Box box) {
        if (box == null) {
            return false;
        }
        return Double.isFinite(box.minX) && Double.isFinite(box.minY) && Double.isFinite(box.minZ) && Double.isFinite(box.maxX) && Double.isFinite(box.maxY) && Double.isFinite(box.maxZ);
    }

    private static Box scaleBox(Box box, float scaleX, float scaleY) {
        if (box == null) {
            return null;
        }
        double cx = (box.minX + box.maxX) * 0.5;
        double cy = (box.minY + box.maxY) * 0.5;
        double cz = (box.minZ + box.maxZ) * 0.5;
        double hx = (box.maxX - box.minX) * 0.5;
        double hy = (box.maxY - box.minY) * 0.5;
        double hz = (box.maxZ - box.minZ) * 0.5;
        double sx = Math.max(0.0, hx * (double)Math.max(1.0f, scaleX));
        double sy = Math.max(0.0, hy * (double)Math.max(1.0f, scaleY));
        double sz = Math.max(0.0, hz * (double)Math.max(1.0f, scaleX));
        return new Box(cx - sx, cy - sy, cz - sz, cx + sx, cy + sy, cz + sz);
    }

    private static void addBox(BufferBuilder buf, Matrix4f mat, Box box, float r, float g, float b, float a) {
        double x1 = box.minX;
        double y1 = box.minY;
        double z1 = box.minZ;
        double x2 = box.maxX;
        double y2 = box.maxY;
        double z2 = box.maxZ;
        Vec3d a1 = new Vec3d(x1, y1, z1);
        Vec3d a2 = new Vec3d(x2, y1, z1);
        Vec3d a3 = new Vec3d(x2, y1, z2);
        Vec3d a4 = new Vec3d(x1, y1, z2);
        Vec3d b1 = new Vec3d(x1, y2, z1);
        Vec3d b2 = new Vec3d(x2, y2, z1);
        Vec3d b3 = new Vec3d(x2, y2, z2);
        Vec3d b4 = new Vec3d(x1, y2, z2);
        BetterHitboxesRenderer.addLine(buf, mat, a1, a2, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, a2, a3, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, a3, a4, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, a4, a1, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, b1, b2, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, b2, b3, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, b3, b4, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, b4, b1, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, a1, b1, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, a2, b2, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, a3, b3, r, g, b, a);
        BetterHitboxesRenderer.addLine(buf, mat, a4, b4, r, g, b, a);
    }

    private static void addLine(BufferBuilder buf, Matrix4f mat, Vec3d a, Vec3d b, float red, float green, float blue, float alpha) {
        float nz;
        float ny;
        float nx;
        Vec3d dir = b.subtract(a);
        double len = dir.length();
        if (len < 1.0E-6) {
            nx = 0.0f;
            ny = 1.0f;
            nz = 0.0f;
        } else {
            nx = (float)(dir.x / len);
            ny = (float)(dir.y / len);
            nz = (float)(dir.z / len);
        }
        buf.vertex(mat, (float)a.x, (float)a.y, (float)a.z).color(red, green, blue, alpha).normal(nx, ny, nz);
        buf.vertex(mat, (float)b.x, (float)b.y, (float)b.z).color(red, green, blue, alpha).normal(nx, ny, nz);
    }
}

