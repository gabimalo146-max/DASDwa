package me.Gui.gui.ui.widget;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import me.Gui.gui.ui.GuiFonts;
import me.Gui.gui.ui.Theme;
import me.Gui.gui.ui.render.Rounded;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class UiTextField {
    public final TextFieldWidget field;
    private int x;
    private int y;
    private int w;
    private int h;
    private final String placeholder;
    private boolean roundRightOnly = false;
    private final int fieldH;
    private float placeholderAnim = 1.0f;
    private static final int PAD = 10;
    private static final List<UiTextField> ALL_FIELDS = new ArrayList<UiTextField>();

    public UiTextField(int x, int y, int w, int h, String placeholder) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        this.placeholder = placeholder == null ? "" : placeholder;
        this.fieldH = h;
        TextRenderer tr = GuiFonts.textRenderer();
        this.field = new TextFieldWidget(tr, x, y, w, h, (Text)Text.literal((String)placeholder));
        this.field.setDrawsBackground(false);
        this.field.setSuggestion("");
        this.field.setMaxLength(64);
        ALL_FIELDS.add(this);
    }

    public void setPos(int x, int y) {
        this.x = x;
        this.y = y;
        this.syncFieldPos();
    }

    public void setSize(int w, int h) {
        this.w = w;
        this.h = h;
        this.field.setWidth(Math.max(0, w - 20));
        this.syncFieldPos();
    }

    public UiTextField setRoundRightOnly(boolean value) {
        this.roundRightOnly = value;
        return this;
    }

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (!this.field.isVisible()) {
            return;
        }
        float R = Math.min((float)this.h * 0.45f, 8.0f);
        int bg = Theme.argb(140, 20, 20, 26);
        if (this.roundRightOnly) {
            Rounded.rectRightRounded(ctx, this.x, this.y, this.w, this.h, R, bg);
        } else {
            Rounded.rect(ctx, this.x, this.y, this.w, this.h, R, bg);
        }
        this.field.render(ctx, mouseX, mouseY, delta);
        boolean showPlaceholder = this.field.getText().isBlank() && !this.field.isFocused() && !this.placeholder.isBlank();
        float target = showPlaceholder ? 1.0f : 0.0f;
        this.placeholderAnim = UiTextField.lerp(this.placeholderAnim, target, 0.25f);
        if (Math.abs(this.placeholderAnim - target) < 0.001f) {
            this.placeholderAnim = target;
        }
        if (this.placeholderAnim > 0.01f) {
            TextRenderer tr = GuiFonts.textRenderer();
            String ph = tr.trimToWidth(this.placeholder, Math.max(0, this.w - 20));
            int tw = tr.getWidth(ph);
            int tx = this.x + (this.w - tw) / 2;
            Objects.requireNonNull(tr);
            int ty = this.y + (this.h - 9) / 2;
            int alpha = Math.max(0, Math.min(255, Math.round(160.0f * this.placeholderAnim)));
            ctx.drawText(tr, (Text)Text.literal((String)ph), tx, ty, Theme.argb(alpha, 185, 185, 198), false);
        }
    }

    public boolean mouseClicked(int mx, int my, int button) {
        boolean inside;
        if (!this.field.isVisible()) {
            return false;
        }
        if (button != 0) {
            return false;
        }
        boolean bl = inside = mx >= this.x && my >= this.y && mx < this.x + this.w && my < this.y + this.h;
        if (!inside) {
            return false;
        }
        int clampX = Math.max(this.x + 10, Math.min(mx, this.x + this.w - 10));
        this.requestFocus();
        this.field.mouseClicked((double)clampX, (double)my, button);
        return true;
    }

    public void requestFocus() {
        for (UiTextField other : ALL_FIELDS) {
            if (other == this) continue;
            other.field.setFocused(false);
        }
        this.field.setFocused(true);
    }

    public static void clearAllFocus() {
        for (UiTextField other : ALL_FIELDS) {
            other.field.setFocused(false);
        }
    }

    private void syncFieldPos() {
        int yOff = Math.max(0, (this.h - this.fieldH) / 2);
        this.field.setX(this.x + 10);
        this.field.setY(this.y + yOff);
    }
}

