# Fastclient — kod źródłowy (Minecraft 1.21.4, Fabric)

Odtworzony kod źródłowy moda **Fastclient-5.jar** (mod Fabric dla Minecrafta **1.21.4**,
Java **21**). Źródła zdekompilowano z JAR-a (CFR 0.152), a następnie zremapowano
z mapowań intermediary na **Yarn 1.21.4+build.8**, dzięki czemu kod jest czytelny
i w pełni przebudowywalny.

## Struktura projektu

```
Fastclient-Source/
├── build.gradle              # konfiguracja builda (Fabric Loom 1.10.5)
├── gradle.properties         # wersje: Minecraft 1.21.4, Yarn, Loader, Fabric API
├── settings.gradle
├── gradlew / gradlew.bat     # Gradle Wrapper 8.14.3
├── gradle/wrapper/
└── src/main/
    ├── java/me/Gui/gui/      # 117 klas Javy (entrypointy, moduły, mixiny, UI)
    │   ├── Gui.java                  # entrypoint "main" (ModInitializer)
    │   ├── client/                   # GuiClient (entrypoint "client"), komendy, keybindy, dźwięki
    │   ├── config/                   # ConfigManager, GuiConfig, JsonUtil
    │   ├── friends/                  # FriendManager
    │   ├── license/                  # LicenseManager, LicenseConfig
    │   ├── mixin/                    # 38 mixinów (gui.mixins.json)
    │   ├── modules/                  # moduły funkcji (AimAssist, Freecam, Xray, ...)
    │   └── ui/                       # GUI, HUD-y, widgety, renderery świata
    └── resources/
        ├── fabric.mod.json           # metadane moda (id: gui, wersja 1.0.0)
        ├── gui.mixins.json           # konfiguracja mixinów
        └── assets/gui/lang/          # tłumaczenia (en_us, pl_pl)
```

## Wymagania

- **JDK 21** (np. Temurin: https://adoptium.net) — Minecraft 1.21.4 wymaga Javy 21
- Internet (Gradle pobiera Minecrafta, mapowania Yarn i Fabric API przy pierwszym buildzie)

## Build

```bash
# Windows
gradlew.bat build

# Linux / macOS
./gradlew build
```

Gotowy mod pojawi się w: `build/libs/fastclient-1.0.0.jar`

## Uruchamianie w środowisku testowym

```bash
./gradlew runClient
```

Otwiera klienta Minecrafta 1.21.4 z załadowanym modem (profil developerski,
katalog `run/`).

## Typowe zadania

| Zadanie | Komenda |
|---|---|
| Build moda | `./gradlew build` |
| Uruchom klienta testowego | `./gradlew runClient` |
| Javy sources (javadoc) | `./gradlew sourcesJar` |
| Generuj refmap mixinów | automatycznie podczas `build` |

## Uwagi techniczne

- **Refmap**: plik `gui.refmap.json` jest generowany automatycznie przez Fabric Loom
  podczas builda (mixin annotation processor) — nie jest przechowywany w źródłach.
- **Mixin compatibility**: `compatibilityLevel: JAVA_21`, `defaultRequire: 0`
  (mixiny nie są twarde — błąd pojedynczego injecta nie wywala gry).
- Wersje zależności ustawione w `gradle.properties`:
  - Minecraft: `1.21.4`
  - Yarn mappings: `1.21.4+build.8`
  - Fabric Loader: `0.19.5` (mod wymaga `>=0.18.4`)
  - Fabric API: `0.119.4+1.21.4`
- Fabric Loader / Fabric API można aktualizować zmieniając wersje w `gradle.properties`.

## Licencja

W `fabric.mod.json` moda deklaruje licencję **All-Rights-Reserved** — kod pozostaje
własnością autora moda.
