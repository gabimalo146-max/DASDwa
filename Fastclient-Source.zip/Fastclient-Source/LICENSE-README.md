Ten projekt jest odtworzonym kodem źródłowym moda Fastclient (fabric.mod.json:
licencja "All-Rights-Reserved"). Całe prawa do oryginalnego moda należą do jego
autora. Niniejszy plik informacyjny nie stanowi licencji na wykorzystanie,
redystrybucję ani modyfikację kodu bez zgody właściciela praw.
